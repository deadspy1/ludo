<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'includes/db.php'; // or adjust path

$username = 'adm';
$email = 'admin@example.com';
$password = 'admin123';
$hashed = password_hash($password, PASSWORD_DEFAULT);

// Check if user already exists
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
if ($stmt->fetch()) {
    echo "Admin user already exists.";
    exit;
}

// Insert admin
$stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, is_admin, balance)
VALUES (?, ?, ?, 1, 0.00)");

if ($stmt->execute([$username, $email, $hashed])) {
    echo "✅ Admin user created successfully.<br>";
    echo "Username: <b>$username</b><br>Password: <b>$password</b>";
} else {
    echo "❌ Failed to create admin.";
}
