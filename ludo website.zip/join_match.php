<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require 'includes/db.php';

$user_id = $_SESSION['user_id'] ?? 0;
if (!$user_id || !isset($_POST['match_id'])) {
    die("Access denied.");
}

$match_id = (int)$_POST['match_id'];

// Fetch the match
$stmt = $pdo->prepare("SELECT * FROM matches WHERE id = ? AND status = 'waiting'");
$stmt->execute([$match_id]);
$match = $stmt->fetch();

if (!$match) {
    die("Match not available.");
}

// Prevent joining own match
if ($match['player1_id'] == $user_id) {
    die("You cannot join your own match.");
}

// Prevent joining full match
if ($match['player2_id']) {
    die("Match already full.");
}

// Check user balance
$stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || $user['balance'] < $match['entry_fee']) {
    die("Insufficient balance to join this match.");
}

// Deduct balance
$pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")
    ->execute([$match['entry_fee'], $user_id]);

// Join match
$pdo->prepare("UPDATE matches SET player2_id = ?, status = 'ongoing' WHERE id = ?")
    ->execute([$user_id, $match_id]);

// Insert system message in chat
$stmt = $pdo->prepare("INSERT INTO match_chat (match_id, user_id, message, created_at) VALUES (?, ?, ?, NOW())");
$stmt->execute([$match_id, $user_id, 'Player has joined the match.']);

// Set session for waiting room
$_SESSION['match_id'] = $match_id;

// Redirect to waiting area
header("Location: waiting_area.php");
exit;
