<?php
session_start();
require 'includes/db.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}

$error = '';
$success = '';
$referrer_id = null;

if (isset($_GET['ref']) && is_numeric($_GET['ref'])) {
    $referrer_id = intval($_GET['ref']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mobile = trim($_POST['mobile'] ?? '');

    if (!preg_match('/^[0-9]{10}$/', $mobile)) {
        $error = "Please enter a valid 10-digit mobile number.";
    } else {
        $otp = rand(100000, 999999);
        $now = date('Y-m-d H:i:s');

        $stmt = $pdo->prepare("SELECT id FROM users WHERE mobile = ?");
        $stmt->execute([$mobile]);
        $user = $stmt->fetch();

        if ($user) {
            $userId = $user['id'];
            $stmt = $pdo->prepare("UPDATE users SET otp_code = ?, otp_created_at = ? WHERE mobile = ?");
            $stmt->execute([$otp, $now, $mobile]);
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO users (mobile, otp_code, otp_created_at, referred_by, balance)
                VALUES (?, ?, ?, ?, 0.00)
            ");
            $stmt->execute([$mobile, $otp, $now, $referrer_id]);
            $userId = $pdo->lastInsertId();
        }

        $_SESSION['otp_mobile'] = $mobile;
        $_SESSION['otp_user_id'] = $userId;

        // Send SMS
        $message = "Welcome to the nxlgames powered by SMSINDIAHUB. Your OTP for registration is $otp";
        $smsApiUrl = "http://cloud.smsindiahub.in/vendorsms/pushsms.aspx";
        $params = [
            'APIKey' => 'OolKGter4ESNowf7s3756w',
            'msisdn' => '91' . $mobile,
            'sid'    => 'SMSHUB',
            'msg'    => $message,
            'fl'     => '0',
            'gwid'   => '2'
        ];

        $smsUrlWithParams = $smsApiUrl . '?' . http_build_query($params);
        $curl = curl_init();
        curl_setopt_array($curl, [ CURLOPT_URL => $smsUrlWithParams, CURLOPT_RETURNTRANSFER => true ]);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            $error = "Failed to send OTP. CURL Error: " . $err;
        } else {
            header("Location: verify_otp.php");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign-up or Sign-in | Super Ludo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Fonts and Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a2d4f46d83.js" crossorigin="anonymous"></script>
    
    <!-- Bootstrap & Custom Style -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #fff;
        }

        .logo {
            max-height: 40px;
        }

        .top-icons {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .card-style {
            max-width: 400px;
            margin: 0 auto;
            border: none;
            box-shadow: none;
        }

        .btn-yellow {
            background-color: #FFDD5C;
            color: #000;
            font-weight: 600;
            border: none;
            width: 100%;
        }

        .btn-yellow:hover {
            background-color: #f8d23a;
        }

        .input-group .form-control {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }

        .promo-text {
            font-size: 1rem;
            text-align: center;
            margin-top: 15px;
            color: #333;
        }

        .legal-text {
            font-size: 0.85rem;
            color: #555;
            text-align: center;
            margin-top: 20px;
        }

        .legal-text a {
            color: #000;
            font-weight: 500;
            text-decoration: underline;
        }

        .dice-img {
            display: block;
            margin: 20px auto 10px;
            width: 60px;
        }

        .header-logo {
            margin: 30px auto 10px;
            text-align: center;
        }

        .header-logo img {
            height: 50px;
        }
    </style>
</head>
<body>

    <div class="container text-center mt-4">
        <div class="header-logo">
            <img src="assets/logo.png" alt="Super Ludo Logo" class="logo">
        </div>

        <div class="top-icons">
            <i class="fas fa-play-circle me-3"></i>
            <i class="fas fa-user-circle"></i>
        </div>

        <div class="mt-4">
            <h4 class="fw-bold">Sign-up or Sign-in</h4>
            <p class="text-muted">Join Over A Million Active Players</p>
        </div>

        <div class="card card-style p-4 mt-3">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="input-group mb-3">
                    <span class="input-group-text bg-light border-end-0" style="border-radius: 10px 0 0 10px;">+91</span>
                    <input type="text" name="mobile" maxlength="10" pattern="\d{10}" class="form-control border-start-0" placeholder="Enter mobile number" required style="border-radius: 0 10px 10px 0;">
                </div>
                <button type="submit" class="btn btn-yellow mt-1">NEXT</button>
            </form>
        </div>

        <div class="promo-text">🪙 Sign up and Get ₹20</div>

        <img src="assets/dice.gif" alt="Dice Illustration" class="dice-img">

        <div class="legal-text">
            By continuing, I hereby confirm that I am 18 years of age or above and I am not playing from Assam, Telangana, Nagaland, Andhra Pradesh, Sikkim and outside India and I agree to the <a href="terms.php">Terms and Conditions</a> and <a href="privacy.php">Privacy Policy</a>.
        </div>
    </div>

</body>
</html>
