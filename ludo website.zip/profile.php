<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_start();
require 'includes/db.php';


$user_id = $_SESSION['user_id'] ?? 0;
if (!$user_id) {
    header("Location: index.php"); // Redirect to login
    exit;
}
require 'includes/header.php';

$stmt = $pdo->prepare("SELECT username, mobile, referral_code, created_at FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) die("User not found.");
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
.profile-card {
    background: #fff;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}
.profile-item {
    padding: 12px 0;
    border-bottom: 1px solid #eee;
}
.profile-item:last-child {
    border-bottom: none;
}
.icon-circle {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: #f1f3f5;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 12px;
}
</style>

<div class="container py-4">
    <h2 class="mb-4 text-center">My Profile</h2>

    <div class="profile-card">
        <div class="d-flex align-items-center profile-item">
            <div class="icon-circle"><i class="fa-solid fa-user text-primary"></i></div>
            <div>
                <div class="fw-bold"><?= htmlspecialchars($user['username']) ?></div>
                <small class="text-muted">Username</small>
            </div>
        </div>

        <div class="d-flex align-items-center profile-item">
            <div class="icon-circle"><i class="fa-solid fa-phone text-success"></i></div>
            <div>
                <div class="fw-bold"><?= htmlspecialchars($user['mobile']) ?></div>
                <small class="text-muted">Mobile Number</small>
            </div>
        </div>

        <div class="d-flex align-items-center profile-item">
            <div class="icon-circle"><i class="fa-solid fa-gift text-warning"></i></div>
            <div>
                <div class="fw-bold"><?= htmlspecialchars($user['referral_code']) ?></div>
                <small class="text-muted">Referral Code</small>
            </div>
        </div>

        <div class="d-flex align-items-center profile-item">
            <div class="icon-circle"><i class="fa-solid fa-calendar text-danger"></i></div>
            <div>
                <div class="fw-bold"><?= date("d M Y", strtotime($user['created_at'])) ?></div>
                <small class="text-muted">Joined On</small>
            </div>
        </div>

        <a href="#" class="btn btn-outline-primary w-100 mt-4 disabled">Edit Profile (Coming Soon)</a>
    </div>

    <a href="dashboard.php" class="btn btn-secondary w-100 mt-4">← Back to Dashboard</a>
</div>

<?php require 'includes/footer.php'; ?>
