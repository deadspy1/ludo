<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Refund Policy - SuperLudo.online</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f8f9fa;
      color: #333;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 900px;
      margin: 50px auto;
      background: #fff;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    h1 {
      color: #d9230f;
      text-align: center;
      margin-bottom: 30px;
    }
    h2 {
      color: #333;
      margin-top: 30px;
    }
    ul {
      padding-left: 20px;
    }
    p {
      margin: 15px 0;
      line-height: 1.6;
    }
    footer {
      margin-top: 50px;
      text-align: center;
      font-size: 14px;
      color: #666;
    }
    a {
      color: #d9230f;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Refund Policy</h1>

    <p><strong>Effective Date:</strong> [10/05/2025]</p>

    <p>At SuperLudo.online, we aim to provide a fair and transparent refund policy for our users.</p>

    <h2>1. Deposits</h2>
    <ul>
      <li>Deposits made into your SuperLudo wallet are considered final and non-refundable except in cases of proven technical errors or failed transactions.</li>
      <li>If a deposit transaction fails but funds are debited from your account, please contact our support team with proof of transaction. Upon verification, the amount will be credited to your SuperLudo wallet.</li>
    </ul>

    <h2>2. Participation Fees</h2>
    <ul>
      <li>Entry fees paid for contests are non-refundable once participation is confirmed.</li>
      <li>In the event a contest is canceled by SuperLudo due to technical issues or lack of participation, entry fees will be refunded to the user’s wallet.</li>
    </ul>

    <h2>3. Withdrawal Issues</h2>
    <ul>
      <li>Withdrawals once processed and transferred are final.</li>
      <li>Any issues related to failed withdrawals will be investigated, and necessary corrective actions will be taken upon verification.</li>
    </ul>

    <h2>4. Disputes</h2>
    <ul>
      <li>Users may raise disputes regarding payments or refunds by contacting our support team at <a href="mailto:support@superludo.online">support@superludo.online</a> within 7 days of the transaction date.</li>
    </ul>

    <h2>5. Policy Updates</h2>
    <ul>
      <li>SuperLudo.online reserves the right to amend this Refund Policy at any time. The updated policy will be available on our website.</li>
    </ul>

    <h2>6. Contact Information</h2>
    <p>
      Email: <a href="mailto:support@superludo.online">support@superludo.online</a><br>
      Phone: [+91 9588170734]<br>
      Address: [Mao, Gurugram, Haryana]
    </p>

    <footer>
      &copy; 2025 SuperLudo.online. All rights reserved.
    </footer>
  </div>
</body>
</html>
