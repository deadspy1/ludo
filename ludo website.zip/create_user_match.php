<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$errors = [];

// Optional pre-fill from URL
$prefill_entry = isset($_GET['entry']) && is_numeric($_GET['entry']) ? intval($_GET['entry']) : '';

// Get user balance
$stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$balance = $user['balance'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $entry_fee = intval($_POST['entry_fee']);

    if ($entry_fee < 50) {
        $errors[] = "Minimum entry fee is ₹50.";
    } elseif ($balance < $entry_fee) {
        $errors[] = "Insufficient balance.";
    } else {
        $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")
            ->execute([$entry_fee, $user_id]);

        $stmt = $pdo->prepare("
            INSERT INTO matches (player1_id, entry_fee, created_by_user, status, created_at)
            VALUES (?, ?, 1, 'waiting', NOW())
        ");
        $stmt->execute([$user_id, $entry_fee]);

        $_SESSION['match_id'] = $pdo->lastInsertId();
        header("Location: waiting_area.php");
        exit;
    }
}
?>

<?php require 'includes/header.php'; ?>

<!-- Bootstrap + Font Awesome -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

<style>
body {
    background: #f2f6ff;
    font-family: 'Poppins', sans-serif;
}
.container {
    max-width: 460px;
    margin: 40px auto 90px;
    background: white;
    padding: 25px;
    border-radius: 18px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.07);
}
.logo {
    display: block;
    margin: 0 auto 20px;
    max-width: 100px;
}
h2 {
    text-align: center;
    font-weight: 600;
    margin-bottom: 25px;
    color: #333;
}
.summary-box {
    background: #fff7e6;
    border: 1px dashed #ffc107;
    padding: 15px;
    border-radius: 10px;
    font-size: 15px;
}
.summary-box p {
    margin-bottom: 6px;
}
.btn-success {
    background-color: #28a745;
    border: none;
}
.btn-success:hover {
    background-color: #218838;
}
.btn-outline-secondary {
    border-color: #ccc;
}
.navbar-bottom {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 60px;
    background: #ffffff;
    border-top: 1px solid #ddd;
    display: flex;
    justify-content: space-around;
    align-items: center;
    z-index: 999;
}
.navbar-bottom a {
    color: #333;
    font-size: 13px;
    text-align: center;
    text-decoration: none;
}
.navbar-bottom .center-btn {
    background: #ffc107;
    color: #000;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    margin-top: -30px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
}
</style>

<div class="container">
    <img src="assets/logo.png" alt="Logo" class="logo">
    <h2>Create Match</h2>

    <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <?php foreach ($errors as $e): ?>
            <div><?= htmlspecialchars($e) ?></div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="entry_fee" class="form-label">Entry Fee (₹)</label>
            <input 
                type="number" 
                name="entry_fee" 
                id="entry_fee" 
                class="form-control" 
                min="50" 
                required 
                value="<?= htmlspecialchars($prefill_entry) ?>"
                oninput="updateSummary()"
            >
        </div>

        <div id="summaryBox" class="summary-box d-none">
            <p>🏆 <strong>Winner gets:</strong> ₹<span id="winAmt">0</span></p>
            <p>📉 <strong>Platform Fee (5%):</strong> ₹<span id="feeAmt">0</span></p>
            <p>💼 <strong>Your Balance:</strong> ₹<?= number_format($balance, 2) ?></p>
        </div>

        <button type="submit" class="btn btn-warning w-100 me-2">Create Match</button>
    </form>

    <a href="dashboard.php" class="btn btn-outline-secondary w-100 mt-3">← Back to Dashboard</a>
</div>



<script>
function updateSummary() {
    const feeInput = document.getElementById('entry_fee');
    const summary = document.getElementById('summaryBox');
    const fee = parseInt(feeInput.value);

    if (fee && fee >= 50) {
        const totalPool = fee * 2;
        const platformFee = totalPool * 0.05;
        const winAmount = totalPool - platformFee;

        document.getElementById('winAmt').textContent = winAmount.toFixed(2);
        document.getElementById('feeAmt').textContent = platformFee.toFixed(2);
        summary.classList.remove('d-none');
    } else {
        summary.classList.add('d-none');
    }
}
window.onload = updateSummary;
</script>

<?php require 'includes/footer.php'; ?>
