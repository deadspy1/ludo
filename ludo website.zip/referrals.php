<?php
session_start();
require 'includes/db.php';

$user_id = $_SESSION['user_id'] ?? 0;
if (!$user_id) {
    header("Location: index.php");
    exit;
}

// Fetch user data
$stmt = $pdo->prepare("SELECT username, referral_code FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Fetch referred users (if any)
$stmt = $pdo->prepare("SELECT username, created_at FROM users WHERE referred_by = ?");
$stmt->execute([$user_id]);
$referrals = $stmt->fetchAll();
?>

<?php require 'includes/header.php'; ?>

<div class="container py-5">
  <div class="card shadow-sm p-4 mb-4">
    <h4 class="mb-3"><i class="fas fa-user-friends me-2"></i>Your Referral Info</h4>

    <p><strong>Your Referral Code:</strong> <span class="text-primary"><?= htmlspecialchars($user['referral_code']) ?></span></p>
    <p><strong>Referral Link:</strong><br>
      <input type="text" class="form-control" readonly value="https://<?= $_SERVER['HTTP_HOST'] ?>/index.php?ref=<?= $user_id ?>" onclick="this.select();">
    </p>

    <div class="alert alert-success mt-3">
      Earn ₹10 when someone registers using your referral link!
    </div>
  </div>

  <div class="card shadow-sm p-4">
    <h5 class="mb-3"><i class="fas fa-list me-2"></i>Your Referrals</h5>

    <?php if (count($referrals) === 0): ?>
      <p class="text-muted">You haven't referred anyone yet.</p>
    <?php else: ?>
      <table class="table table-sm table-bordered align-middle">
        <thead class="table-light">
          <tr>
            <th>Username</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($referrals as $r): ?>
            <tr>
              <td><?= htmlspecialchars($r['username']) ?></td>
              <td><?= date('d M Y, h:i A', strtotime($r['created_at'])) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
