<?php
session_start();
require 'includes/db.php';
require 'includes/header.php';

$user_id = $_SESSION['user_id'] ?? 0;

// Fetch balance
$stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$balance = $stmt->fetchColumn();

// Match History
$matchStmt = $pdo->prepare("
    SELECT m.*, u1.username AS p1_name, u2.username AS p2_name
    FROM matches m
    LEFT JOIN users u1 ON m.player1_id = u1.id
    LEFT JOIN users u2 ON m.player2_id = u2.id
    WHERE m.player1_id = ? OR m.player2_id = ?
    ORDER BY m.created_at DESC LIMIT 20
");
$matchStmt->execute([$user_id, $user_id]);
$matches = $matchStmt->fetchAll();

// Transactions
$tx = $pdo->prepare("SELECT * FROM wallet_requests WHERE user_id = ? ORDER BY requested_at DESC LIMIT 20");
$tx->execute([$user_id]);
$transactions = $tx->fetchAll();
?>

<!-- Bootstrap, Font Awesome, AOS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

<style>
body {
      font-family: 'Outfit', sans-serif;
      background: linear-gradient(to bottom, #fffbea, #ffe5b4);
      margin-bottom: 90px;
    }
}
h2, h5 {
    font-weight: 600;
}
.balance-card {
    background: linear-gradient(135deg, #fff6d8, #fff);
    border: 2px solid #ffca28;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.07);
    text-align: center;
}
    .balance-box {
      position: absolute;
      top: 20px;
      right: 20px;
      background: #fff;
      border: 2px solid #FFDD5C;
      padding: 6px 16px;
      border-radius: 50px;
      font-weight: 600;
      font-size: 14px;
      color: #000;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      z-index: 1000;
    }
.wallet-btn {
    width: 48%;
    font-weight: 600;
}
.tx-box {
    background: #fff;
    border-radius: 12px;
    padding: 15px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    margin-bottom: 12px;
}
.badge {
    font-size: 13px;
    padding: 6px 10px;
    border-radius: 20px;
}
.filter-select {
    max-width: 180px;
}
.nav-tabs .nav-link.active {
    background-color: #ffca28 !important;
    color: #000 !important;
    font-weight: bold;
}
.navbar-bottom {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 60px;
    background-color: #fff;
    display: flex;
    justify-content: space-around;
    align-items: center;
    border-top: 1px solid #ddd;
    z-index: 1000;
}
.navbar-bottom a {
    color: #555;
    text-decoration: none;
    font-size: 13px;
    display: flex;
    flex-direction: column;
    align-items: center;
}
.navbar-bottom a.active {
    color: #ffca28;
    font-weight: bold;
}
.navbar-bottom .center-btn {
    background-color: #ffca28;
    color: black;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    margin-top: -30px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}
.navbar-bottom a i {
    font-size: 18px;
}
a {
    color: inherit;
    text-decoration: none;
}

a:hover {
    color: #ffca28;
    text-decoration: none;
}
a.btn {
    color: #000;
}

a.btn:hover {
    color: #000;
    opacity: 0.9;
}

</style>

 <div class="d-flex justify-content-between align-items-center mb-3">
            <img src="assets/logo.png" alt="Logo" class="logo">
            <div class="top-icons">
                <i class="fa-solid me-1 text-warning">  <div class="balance-box">

    <a href="wallet.php"><i class="fa-solid fa-coins me-1 text-warning"><i style="color:black;">
      ₹ <?= number_format($balance ?? 0, 0) ?></i></i>
    </a>
  </div></i>
            </div>
        </div>
<div class="container py-4">
    <h2 class="text-center mb-4">My Wallet</h2>

    <!-- Balance Card -->
    <div class="balance-card mb-4" data-aos="fade-down">
        <div class="text-muted mb-2">Wallet Balance</div>
        <h4><i class="fa-solid fa-wallet text-warning me-2"></i> ₹<?= number_format($balance, 0) ?></h4>
    </div>

    <!-- Action Buttons -->
    <div class="d-flex justify-content-between mb-4">
        <a href="add_funds.php" class="btn btn-warning wallet-btn"><i class="fa-solid fa-plus me-1"></i> Add Funds</a>
        <a href="withdraw_request.php" class="btn btn-outline-primary wallet-btn"><i class="fa-solid fa-arrow-up-from-bracket me-1"></i> Withdraw</a>
    </div>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-3" id="walletTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="matches-tab" data-bs-toggle="tab" data-bs-target="#matches" type="button">Match History</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="transactions-tab" data-bs-toggle="tab" data-bs-target="#transactions" type="button">Recent Activity</button>
        </li>
    </ul>

    <div class="tab-content">
        <!-- Match History Tab -->
        <div class="tab-pane fade show active" id="matches" role="tabpanel">
            <div class="d-flex justify-content-end mb-2">
                <select id="matchFilter" class="form-select form-select-sm filter-select">
                    <option value="all">All</option>
                    <option value="won">Won</option>
                    <option value="lost">Lost</option>
                </select>
            </div>

            <div id="matchList">
                <?php if (empty($matches)): ?>
                    <div class="text-muted text-center">No matches played yet.</div>
                <?php else: ?>
                    <?php foreach ($matches as $match): 
                        $opponent = $user_id == $match['player1_id'] ? $match['p2_name'] : $match['p1_name'];
                        $result = 'Pending';
                        if ($match['winner_id']) {
                            $result = $match['winner_id'] == $user_id ? 'Won' : 'Lost';
                        }
                    ?>
                        <div class="tx-box match-item" data-result="<?= strtolower($result) ?>" data-aos="fade-up">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>Match #<?= $match['id'] ?></strong> vs <?= htmlspecialchars($opponent) ?><br>
                                    <small class="text-muted"><?= date("d M Y, h:i A", strtotime($match['created_at'])) ?></small><br>
                                    <small>Entry Fee: ₹<?= $match['entry_fee'] ?></small>
                                </div>
                                <span class="badge bg-<?= $result === 'Won' ? 'success' : ($result === 'Lost' ? 'danger' : 'secondary') ?>"><?= $result ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Transactions Tab -->
        <div class="tab-pane fade" id="transactions" role="tabpanel">
            <div class="d-flex justify-content-end mb-2">
                <select id="txFilter" class="form-select form-select-sm filter-select">
                    <option value="all">All</option>
                    <option value="deposit">Deposits</option>
                    <option value="withdrawal">Withdrawals</option>
                </select>
            </div>

            <div id="txList">
                <?php if (empty($transactions)): ?>
                    <div class="text-muted text-center">No recent transactions.</div>
                <?php else: ?>
                    <?php foreach ($transactions as $tx): ?>
                        <div class="tx-box tx-item" data-type="<?= strtolower($tx['type']) ?>" data-aos="fade-up">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><i class="fa-solid fa-<?= $tx['type'] === 'deposit' ? 'arrow-down text-success' : 'arrow-up text-danger' ?>"></i> <?= ucfirst($tx['type']) ?></strong> ₹<?= number_format($tx['amount'], 2) ?><br>
                                    <small class="text-muted"><?= date("d M Y, h:i A", strtotime($tx['created_at'])) ?></small>
                                </div>
                                <span class="badge bg-<?= $tx['status'] === 'approved' ? 'success' : ($tx['status'] === 'pending' ? 'warning' : 'danger') ?>"><?= ucfirst($tx['status']) ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <a href="dashboard.php" class="btn btn-secondary mt-4 w-100">← Back to Dashboard</a>
</div>
<!-- Bottom Navigation -->
<div class="navbar-bottom">
  <a href="join_tournament.php">
    <i class="fa-solid fa-dice"></i>
    <span>Play</span>
  </a>
  <a href="referrals.php">
    <i class="fa-solid fa-users"></i>
    <span>Referral</span>
  </a>
  <a href="add_funds.php" class="center-btn">
    <i class="fa-solid fa-indian-rupee-sign"></i>
  </a>
  <a href="wallet.php" class="active">
    <i class="fa-solid fa-wallet"></i>
    <span>Wallet</span>
  </a>
  <a href="profile.php">
    <i class="fa-solid fa-user"></i>
    <span>Profile</span>
  </a>
</div>
<!-- JS Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
AOS.init();

// Match Filter
document.getElementById('matchFilter').addEventListener('change', function() {
    const value = this.value;
    document.querySelectorAll('.match-item').forEach(el => {
        if (value === 'all' || el.dataset.result === value) {
            el.style.display = 'block';
        } else {
            el.style.display = 'none';
        }
    });
});

// Transaction Filter
document.getElementById('txFilter').addEventListener('change', function() {
    const value = this.value;
    document.querySelectorAll('.tx-item').forEach(el => {
        if (value === 'all' || el.dataset.type === value) {
            el.style.display = 'block';
        } else {
            el.style.display = 'none';
        }
    });
});
</script>

<?php require 'includes/footer.php'; ?>
