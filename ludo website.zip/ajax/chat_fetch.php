<?php
require '../includes/db.php';
require '../includes/auth.php';

$match_id = intval($_GET['match_id']);

$stmt = $pdo->prepare("SELECT c.*, u.username FROM chat_messages c JOIN users u ON c.sender_id = u.id WHERE match_id = ? ORDER BY created_at ASC");
$stmt->execute([$match_id]);
$chats = $stmt->fetchAll();

foreach ($chats as $chat) {
    echo "<p><strong>" . htmlspecialchars($chat['username']) . ":</strong> " . htmlspecialchars($chat['message']) . "</p>";
}
