<?php
require '../includes/db.php';
require '../includes/auth.php';

$match_id = intval($_POST['match_id']);
$game_code = trim($_POST['game_code']);
$user_id = $_SESSION['user_id'];

if (!$game_code) {
    echo "Code is required.";
    exit;
}

// Only allow if game_code is not already set
$stmt = $pdo->prepare("SELECT * FROM matches WHERE id = ? AND game_code IS NULL");
$stmt->execute([$match_id]);
$match = $stmt->fetch();

if (!$match) {
    echo "Game code already set.";
    exit;
}

$stmt = $pdo->prepare("UPDATE matches SET game_code = ?, host_id = ? WHERE id = ?");
$stmt->execute([$game_code, $user_id, $match_id]);

echo "Game code submitted!";
