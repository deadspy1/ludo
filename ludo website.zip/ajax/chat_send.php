<?php
require '../includes/db.php';
require '../includes/auth.php';

$match_id = intval($_POST['match_id']);
$message = trim($_POST['message']);
$sender_id = $_SESSION['user_id'];

if ($message) {
    $stmt = $pdo->prepare("INSERT INTO chat_messages (match_id, sender_id, message) VALUES (?, ?, ?)");
    $stmt->execute([$match_id, $sender_id, $message]);
}
