<?php
session_start();
require 'includes/db.php';
require 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT m.*, t.name AS tournament_name,
           u1.username AS p1_name, u2.username AS p2_name
    FROM matches m
    JOIN tournaments t ON m.tournament_id = t.id
    LEFT JOIN users u1 ON m.player1_id = u1.id
    LEFT JOIN users u2 ON m.player2_id = u2.id
    WHERE m.status = 'completed' AND (player1_id = ? OR player2_id = ?)
    ORDER BY m.created_at DESC
");
$stmt->execute([$user_id, $user_id]);
$matches = $stmt->fetchAll();
?>

<h2 class="mb-4">Match History</h2>

<?php if (empty($matches)): ?>
    <div class="alert alert-info">You have no completed matches yet.</div>
<?php else: ?>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Date</th>
                <th>Tournament</th>
                <th>Opponent</th>
                <th>Result</th>
                <th>Reward</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($matches as $m): ?>
                <tr>
                    <td><?= date('d M Y, h:i A', strtotime($m['created_at'])) ?></td>
                    <td><?= htmlspecialchars($m['tournament_name']) ?></td>
                    <td>
                        <?= $user_id == $m['player1_id']
                            ? htmlspecialchars($m['p2_name'])
                            : htmlspecialchars($m['p1_name']) ?>
                    </td>
                    <td>
                        <?php
                        if ($m['winner_id'] == $user_id) echo '<span class="text-success">Won</span>';
                        elseif ($m['winner_id']) echo '<span class="text-danger">Lost</span>';
                        else echo '<span class="text-muted">Pending</span>';
                        ?>
                    </td>
                    <td>
                        <?php if ($m['winner_id'] == $user_id): ?>
                            ₹<?= number_format($m['prize'] ?? $m['reward'] ?? 0, 2) ?>
                        <?php else: ?>
                            –
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<a href="dashboard.php" class="btn btn-secondary mt-3">← Back to Dashboard</a>

<?php require 'includes/footer.php'; ?>
