<?php
session_start();

// Only logout if logout=true is passed
if (!isset($_GET['logout']) || $_GET['logout'] !== 'true') {
    header("Location: dashboard"); // redirect back if not valid
    exit;
}

session_destroy();
header("Location: index");
exit;
?>
