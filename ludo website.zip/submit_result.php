<?php
session_start();
require 'includes/db.php';

$user_id = $_SESSION['user_id'] ?? 0;
$match_id = $_SESSION['match_id'] ?? 0;

if (!$user_id || !$match_id) {
    die("Access denied.");
}

// Fetch match info
$stmt = $pdo->prepare("
    SELECT m.*, 
           t.name AS tournament_name, 
           u1.username AS p1_name, 
           u2.username AS p2_name 
    FROM matches m
    LEFT JOIN tournaments t ON m.tournament_id = t.id
    LEFT JOIN users u1 ON m.player1_id = u1.id
    LEFT JOIN users u2 ON m.player2_id = u2.id
    WHERE m.id = ?
");
$stmt->execute([$match_id]);
$match = $stmt->fetch();

if (!$match) die("Match not found.");

$message = '';

// Handle Screenshot Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['screenshot'])) {
    $file = $_FILES['screenshot'];
    $uploadDir = 'uploads/';
    $filename = uniqid() . '_' . basename($file['name']);
    $targetPath = $uploadDir . $filename;

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        if ($match['player1_id'] == $user_id) {
            $stmt = $pdo->prepare("UPDATE matches SET screenshot1 = ? WHERE id = ?");
        } else {
            $stmt = $pdo->prepare("UPDATE matches SET screenshot2 = ? WHERE id = ?");
        }
        $stmt->execute([$targetPath, $match_id]);
        $message = "Screenshot uploaded successfully for Admin Review.";
        // Refresh match data after update
        $stmt = $pdo->prepare("
            SELECT m.*, 
                   t.name AS tournament_name, 
                   u1.username AS p1_name, 
                   u2.username AS p2_name 
            FROM matches m
            LEFT JOIN tournaments t ON m.tournament_id = t.id
            LEFT JOIN users u1 ON m.player1_id = u1.id
            LEFT JOIN users u2 ON m.player2_id = u2.id
            WHERE m.id = ?
        ");
        $stmt->execute([$match_id]);
        $match = $stmt->fetch();
    } else {
        $message = "Upload failed. Please try Again.";
    }
}

// Check if both screenshots are uploaded
$both_screens_uploaded = $match['screenshot1'] && $match['screenshot2'];

// Handle Winner Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['winner_id']) && $both_screens_uploaded) {
    $winner_id = intval($_POST['winner_id']);
    if (in_array($winner_id, [$match['player1_id'], $match['player2_id']])) {
        $stmt = $pdo->prepare("UPDATE matches SET winner_id = ? WHERE id = ?");
        $stmt->execute([$winner_id, $match_id]);
        $message = "\ud83c\udf89 Winner submitted successfully!";
        $match['winner_id'] = $winner_id;
    } else {
        $message = "\u274C Invalid winner selection.";
    }
}
?>

<?php require 'includes/header.php'; ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
    body {
      font-family: 'Outfit', sans-serif;
      background: linear-gradient(to bottom, #fffbea, #ffe5b4);
      margin-bottom: 90px;
    }
    .card {
        border: 2px solid #ffc107;
        border-radius: 12px;
        background: #fff;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .btn-primary {
        background-color: #FFD600;
        color: #000;
        border: none;
        font-weight: bold;
        border-radius: 8px;
    }
    .btn-primary:hover {
        background-color: #e6c200;
    }
    .btn-secondary {
        background-color: #000;
        color: #FFD600;
        border-radius: 8px;
    }
    .alert-info {
        background-color: #fff8dc;
        border-left: 4px solid #ffc107;
        color: #333;
        font-weight: 600;
    }
    .form-control {
        border: 1px solid #ccc;
        border-radius: 8px;
    }
    h4, h5 {
        color: #000;
        font-weight: 700;
    }
</style>

<div class="container py-4">
    <div class="text-center mb-4">
        <img src="assets/logo.png" alt="Logo" class="img-fluid" style="height: 50px;">
    </div>

    <div class="card p-4 mb-4">
        <h4 class="text-center mb-3"><i class="fas fa-dice text-warning me-2"></i>Match Summary</h4>
        <div class="row text-center">
            <div class="col-4">
                <div class="text-muted">Match ID</div>
                <div class="fw-bold">#<?= $match['id'] ?></div>
            </div>
            <div class="col-4">
                <div class="text-muted">Entry Fee</div>
                <div class="fw-bold text-danger">₹<?= number_format($match['entry_fee'], 2) ?></div>
            </div>
            <div class="col-4">
                <div class="text-muted">Prize Pool</div>
                <div class="fw-bold text-success">₹<?= number_format($match['entry_fee'] * 2 * 0.95, 2) ?></div>
            </div>
        </div>
    </div>

    <div class="card p-4 mb-4">
        <h4 class="mb-3"><i class="fas fa-upload text-warning me-2"></i>Submit Match Result</h4>

        <?php if ($match['tournament_name']): ?>
            <p><strong>Tournament:</strong> <?= htmlspecialchars($match['tournament_name']) ?></p>
        <?php endif; ?>

        <p><strong>Your Opponent:</strong> <?= $user_id == $match['player1_id'] ? htmlspecialchars($match['p2_name']) : htmlspecialchars($match['p1_name']) ?></p>

        <?php if ($message): ?>
            <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="screenshot" class="form-label">Upload Screenshot</label>
                <input type="file" name="screenshot" id="screenshot" class="form-control" accept="image/*" required>
            </div>
            <button type="submit" class="btn btn-primary w-100"><i class="fas fa-paper-plane me-1"></i>Submit Screenshot</button>
        </form>

       
    </div>

    <a href="dashboard.php" class="btn btn-secondary w-100"><i class="fas fa-arrow-left me-2"></i>Back to Dashboard</a>
</div>

<?php require 'includes/footer.php'; ?>
