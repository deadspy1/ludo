<?php
session_start();
require 'includes/db.php';

$user_id = $_SESSION['user_id'] ?? 0;
$match_id = $_POST['match_id'] ?? 0;
$message = trim($_POST['message'] ?? '');

if ($user_id && $match_id && $message !== '') {
    $stmt = $pdo->prepare("INSERT INTO match_chat (match_id, user_id, message) VALUES (?, ?, ?)");
    $stmt->execute([$match_id, $user_id, $message]);
}
header("Location: waiting_area.php");
exit;
