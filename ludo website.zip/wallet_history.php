<?php
session_start();
require 'includes/db.php';
require 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT * FROM wallet_requests 
    WHERE user_id = ? 
    ORDER BY requested_at DESC
");
$stmt->execute([$user_id]);
$requests = $stmt->fetchAll();
?>

<h2 class="mb-4">Wallet Request History</h2>

<?php if (empty($requests)): ?>
    <div class="alert alert-info">You haven’t made any wallet requests yet.</div>
<?php else: ?>
<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Amount (₹)</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($requests as $r): ?>
        <tr>
            <td><?= date('d M Y, h:i A', strtotime($r['requested_at'])) ?></td>
            <td><?= ucfirst($r['type']) ?></td>
            <td>₹<?= number_format($r['amount'], 2) ?></td>
            <td>
                <?php
                switch ($r['status']) {
                    case 'approved': echo '<span class="text-success">Approved</span>'; break;
                    case 'rejected': echo '<span class="text-danger">Rejected</span>'; break;
                    default: echo '<span class="text-warning">Pending</span>';
                }
                ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>

<a href="dashboard.php" class="btn btn-secondary mt-3">← Back to Dashboard</a>

<?php require 'includes/footer.php'; ?>
