<?php
session_start();
require 'includes/db.php';

$user_id = $_SESSION['user_id'] ?? 0;
if (!$user_id) {
    die("You must be logged in to join a tournament.");
}

$tournament_id = $_POST['tournament_id'] ?? 0;

// Fetch tournament
$stmt = $pdo->prepare("SELECT * FROM tournaments WHERE id = ? AND status = 'open'");
$stmt->execute([$tournament_id]);
$tournament = $stmt->fetch();

if (!$tournament) {
    die("Tournament not found or closed.");
}

// Check user's balance
$stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || $user['balance'] < $tournament['entry_fee']) {
    die("Insufficient balance to join.");
}

// Deduct entry fee
$stmt = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
$stmt->execute([$tournament['entry_fee'], $user_id]);

// Try to find an open match
$stmt = $pdo->prepare("SELECT * FROM matches WHERE tournament_id = ? AND player2_id IS NULL AND status = 'waiting' LIMIT 1");
$stmt->execute([$tournament_id]);
$openMatch = $stmt->fetch();

if ($openMatch) {
    // Join existing match as player 2 and mark ongoing
    $stmt = $pdo->prepare("UPDATE matches SET player2_id = ?, status = 'ongoing' WHERE id = ?");
    $stmt->execute([$user_id, $openMatch['id']]);
    $match_id = $openMatch['id'];
} else {
    // ✅ Fixed: Save entry_fee in match for refund support
    $stmt = $pdo->prepare("INSERT INTO matches (tournament_id, player1_id, entry_fee, status) VALUES (?, ?, ?, 'waiting')");
    $stmt->execute([$tournament_id, $user_id, $tournament['entry_fee']]);
    $match_id = $pdo->lastInsertId();
}

// Store match ID in session
$_SESSION['match_id'] = $match_id;

// Redirect to waiting area
header("Location: waiting_area.php");
exit;
