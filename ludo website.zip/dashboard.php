<?php
session_start();

require 'includes/db.php';
require 'includes/header.php';
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] == 0) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'] ?? 0;

// Fetch balance
$stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$balance = $stmt->fetchColumn();

// Fetch username
$stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$username = $stmt->fetchColumn();

// Check for active match
$stmt = $pdo->prepare("SELECT id, entry_fee, created_at, player1_id, player2_id FROM matches WHERE (player1_id = :uid OR player2_id = :uid) AND winner_id IS NULL ORDER BY created_at DESC LIMIT 1");
$stmt->execute(['uid' => $user_id]);
$active_match = $stmt->fetch(PDO::FETCH_ASSOC);

$player1_name = $player2_name = '';

if ($active_match) {
    $_SESSION['match_id'] = $active_match['id'];

    // Fetch player1 username
    $player1Stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $player1Stmt->execute([$active_match['player1_id']]);
    $player1_name = $player1Stmt->fetchColumn() ?: 'Player 1';

    // Fetch player2 username
    $player2Stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $player2Stmt->execute([$active_match['player2_id']]);
    $player2_name = $player2Stmt->fetchColumn() ?: 'Player 2';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard | Super Ludo</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Outfit', sans-serif;
      background: linear-gradient(to bottom, #fffbea, #ffe5b4);
      margin-bottom: 90px;
    }
    
    .match-box {
        background: #fff;
        border-radius: 12px;
        padding: 15px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        margin-bottom: 15px;
    }
    .match-box.user-hosted {
        border: 2px solid #ffca28;
    }
    .match-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .match-label {
        font-size: 14px;
        color: #555;
    }
    .match-value {
        font-size: 16px;
        font-weight: bold;
    }
    .play-btn {
        background: #ffc107;
        border: none;
        padding: 6px 20px;
        border-radius: 30px;
        font-weight: bold;
        color: #000;
    }
    .vs-text {
        text-align: center;
        font-weight: bold;
        font-size: 15px;
        color: #555;
    }
    .game-title {
      font-size: 1.2rem;
      font-weight: 700;
    }
    .game-desc {
      font-size: 0.9rem;
      color: #555;
    }
    .card-game {
      border-radius: 16px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.08);
      overflow: hidden;
      margin-bottom: 20px;
    }
    .card-game img {
      width: 100%;
      height: auto;
    }
    .card-game .card-body {
      background: #fff;
    }
    .btn-yellow {
      background-color: #FFD600;
      color: #000;
      font-weight: 600;
      border-radius: 8px;
    }
    .card-kyc {
      background: linear-gradient(45deg, #240046, #5A189A);
      color: #fff;
      padding: 16px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 20px;
    }
    .card-kyc img {
      width: 40px;
      height: 40px;
    }
    .footer-nav {
      position: fixed;
      bottom: 0;
      left: 0;
      width: 100%;
      background: #fff;
      border-top: 1px solid #eee;
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 10px 0;
    }
    .footer-nav a {
      color: #999;
      font-size: 12px;
      text-align: center;
    }
    .footer-nav a.active {
      color: #FFD600;
    }
    .footer-nav i {
      font-size: 20px;
      display: block;
    }
    .footer-nav .center-btn {
      background: #fff;
      border: 3px solid #FFD600;
      width: 65px;
      height: 65px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-top: -30px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .balance-box {
      position: absolute;
      top: 20px;
      right: 20px;
      background: #fff;
      border: 2px solid #FFDD5C;
      padding: 6px 16px;
      border-radius: 50px;
      font-weight: 600;
      font-size: 14px;
      color: #000;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      z-index: 1000;
    }
  </style>
</head>
<body>
  <!-- Balance & Header Area -->
  <div class="d-flex justify-content-between align-items-center mb-3">
            <img src="assets/logo.png" alt="Logo" class="logo">
            <div class="top-icons">
                <i class="fa-solid me-1 text-warning">  <div class="balance-box">

    <a href="wallet.php"><i class="fa-solid fa-coins me-1 text-warning"><i style="color:black;">
      ₹ <?= number_format($balance ?? 0, 0) ?></i></i>
    </a>
  </div></i>
            </div>
        </div>
<br/><br/>
  <div class="container">
  <h4 class="mb-2">Welcome, <span class="text-danger"><?= htmlspecialchars($username) ?></span> <span class="wave"></span></h4>
   <br/>


 <!-- Active / Resume Match -->


  <?php if ($active_match): ?>
    <i class="text-success fw-medium mb-2"><strong><i class="fa-solid fa-dice"></i> Active Match</strong></i>
  <div class="match-box user-hosted">
    <div class="match-info mb-2">
      <div>
        <div class="match-label">Prize</div>
        <div class="match-value text-success">₹<?= $active_match['prize'] ?? $active_match['prize_pool'] ?? ($active_match['entry_fee'] * 1.9) ?></div>
      </div>
      <div>
        <div class="match-label">Entry</div>
        <div class="match-value text-danger">₹<?= htmlspecialchars($active_match['entry_fee']) ?></div>
      </div>
      <div>
        <form method="POST" action="waiting_area.php">
          <input type="hidden" name="match_id" value="<?= $active_match['id'] ?>">
          <button type="submit" class="play-btn">RESUME</button>
        </form>
      </div>
    </div>
    <div class="d-flex justify-content-between align-items-center mt-2">
      <div class="small text-muted">⏰ <?= date('d M Y, h:i A', strtotime($active_match['created_at'])) ?></div>
     <div class="text-muted small"><?= htmlspecialchars($player1_name) ?> vs <?= htmlspecialchars($player2_name) ?></div>
    </div>
  </div>
  <?php else: ?>
 
  <?php endif; ?>
   


    <!-- Ludo League + Create Match -->
    <i class="text-success fw-medium mb-2"><strong><i class="fa-solid fa-dice"></i> Main Menu</strong></i>
    <div class="row">
      <div class="col-6">
        <div class="card-game">
          <img src="uploads/host_img.webp" alt="Host Match">
          <div class="card-body text-center">
           
            <a href="create_user_match.php" class="btn btn-yellow mt-2 w-100">Create Match</a>
          </div>
        </div>
      </div>

      <!-- 1 Token Ludo -->
      <div class="col-6">
        <div class="card-game">
          <img src="uploads/join_img.webp" alt="Join Match">
          <div class="card-body text-center">
            
            <a href="join_tournament.php" class="btn btn-yellow mt-2 w-100">Play Now</a>
          </div>
        </div>
      </div>
    </div>

    <!-- KYC -->
    <div class="card-kyc">
      <i class="fa-solid fa-user"></i>
      <div class="flex-grow-1">
        <div class="fw-bold">Live Support</div>
        <small>For Any kind of Support, Feel free to message us!</small>
      </div>
      <a href="#" class="btn btn-sm btn-yellow">Chat Now</a>
    </div>
  </div>

  <!-- Footer Navigation -->
  <div class="footer-nav">
    <a href="join_tournament.php" class="active">
      <i class="fa-solid fa-dice"></i>
      <span>Play</span>
    </a>
    <a href="referrals.php">
      <i class="fa-solid fa-users"></i>
      <span>Referral</span>
    </a>
    <a href="add_funds.php" class="center-btn">
      <i class="fa-solid fa-indian-rupee-sign"></i>
    </a>
    <a href="wallet.php">
      <i class="fa-solid fa-wallet"></i>
      <span>Wallet</span>
    </a>
    <a href="profile.php">
      <i class="fa-solid fa-user"></i>
      <span>Profile</span>
    </a>
  </div>

  <?php require 'includes/footer.php'; ?>
</body>
</html>
