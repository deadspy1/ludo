<?php
require '../includes/db.php';
require 'admin_auth.php';

$request_id = intval($_POST['request_id'] ?? 0);
$action     = $_POST['action'] ?? '';

if (!$request_id || !in_array($action, ['approve', 'reject'])) {
    die("Invalid request.");
}

// Fetch request
$stmt = $pdo->prepare("SELECT * FROM wallet_requests WHERE id = ?");
$stmt->execute([$request_id]);
$request = $stmt->fetch();

if (!$request || $request['status'] !== 'pending') {
    die("Request not found or already handled.");
}

$user_id = $request['user_id'];
$amount  = $request['amount'];
$type    = $request['type'];

if ($action === 'approve') {
    $pdo->beginTransaction();

    try {
        // Only add amount if it's an add request (already deducted if withdraw)
        if ($type === 'add') {
            $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
            $stmt->execute([$amount, $user_id]);
        }

        // Mark as approved
        $stmt = $pdo->prepare("UPDATE wallet_requests SET status = 'approved' WHERE id = ?");
        $stmt->execute([$request_id]);

        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        die("Transaction failed: " . $e->getMessage());
    }
} else {
    $pdo->beginTransaction();

    try {
        // Refund if rejected and it's a withdraw request
        if ($type === 'withdraw') {
            $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
            $stmt->execute([$amount, $user_id]);
        }

        // Mark as rejected
        $stmt = $pdo->prepare("UPDATE wallet_requests SET status = 'rejected' WHERE id = ?");
        $stmt->execute([$request_id]);

        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        die("Failed to reject and refund: " . $e->getMessage());
    }
}

header("Location: wallet_requests.php");
exit;
