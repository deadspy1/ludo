<?php
require '../includes/db.php';
require 'admin_auth.php';

$stmt = $pdo->query("
    SELECT m.*, 
           u1.username AS p1_name, 
           u2.username AS p2_name,
           t.name AS tournament_name
    FROM matches m
    LEFT JOIN users u1 ON m.player1_id = u1.id
    LEFT JOIN users u2 ON m.player2_id = u2.id
    LEFT JOIN tournaments t ON m.tournament_id = t.id
    WHERE (m.screenshot1 IS NOT NULL OR m.screenshot2 IS NOT NULL)
      AND m.winner_id IS NULL
    ORDER BY m.created_at DESC
");
$matches = $stmt->fetchAll();
?>

<?php require '../includes/header.php'; ?>
<div class="container py-4">
    <h2>🧾 Pending Match Reviews</h2>

    <?php if (empty($matches)): ?>
        <div class="alert alert-info">No matches with screenshots to review.</div>
    <?php else: ?>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Match Type</th>
                <th>Players</th>
                <th>Screenshots</th>
                <th>Entry Fee</th>
                <th>Created</th>
                <th>Declare Winner</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($matches as $match): ?>
            <tr>
                <td><?= $match['id'] ?></td>
                <td>
                    <?= $match['created_by_user'] ? '<span class="badge bg-success">User Match</span>' : '<span class="badge bg-primary">Admin Tournament</span>' ?>
                    <?php if ($match['tournament_name']): ?><br><small><?= htmlspecialchars($match['tournament_name']) ?></small><?php endif; ?>
                </td>
                <td><?= htmlspecialchars($match['p1_name']) ?> vs <?= htmlspecialchars($match['p2_name']) ?></td>
                <td>
                    <?php if ($match['screenshot1']): ?>
                        <a href="../<?= $match['screenshot1'] ?>" target="_blank">Player 1</a>
                    <?php endif; ?>
                    <?php if ($match['screenshot2']): ?>
                        | <a href="../<?= $match['screenshot2'] ?>" target="_blank">Player 2</a>
                    <?php endif; ?>
                </td>
                <td>₹<?= $match['entry_fee'] ?></td>
                <td><?= date("d M Y, h:i A", strtotime($match['created_at'])) ?></td>
                <td>
                    <form method="POST" action="mark_winner.php">
                        <input type="hidden" name="match_id" value="<?= $match['id'] ?>">
                        <select name="winner_id" class="form-select mb-2" required>
                            <option value="<?= $match['player1_id'] ?>">✅ <?= htmlspecialchars($match['p1_name']) ?></option>
                            <option value="<?= $match['player2_id'] ?>">✅ <?= htmlspecialchars($match['p2_name']) ?></option>
                        </select>
                        <button type="submit" class="btn btn-success btn-sm w-100">Declare Winner</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <a href="dashboard.php" class="btn btn-secondary mt-3">← Back to Dashboard</a>
</div>

<?php require '../includes/footer.php'; ?>
