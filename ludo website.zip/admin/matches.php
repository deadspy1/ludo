<?php
require '../includes/db.php';
require 'admin_auth.php';
require '../includes/header.php';

$matches = $pdo->query("SELECT m.*, u1.username AS player1, u2.username AS player2, t.name AS tournament_name FROM matches m
LEFT JOIN users u1 ON m.player1_id = u1.id
LEFT JOIN users u2 ON m.player2_id = u2.id
LEFT JOIN tournaments t ON m.tournament_id = t.id
ORDER BY m.created_at DESC LIMIT 100")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Matches | Admin Panel</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .badge-status {
      font-size: 0.8rem;
      padding: 5px 10px;
      border-radius: 12px;
    }
    .badge-waiting { background-color: #ffc107; color: #000; }
    .badge-completed { background-color: #28a745; color: #fff; }
    .badge-cancelled { background-color: #dc3545; color: #fff; }
    .action-btn { font-size: 14px; margin-right: 5px; }
  </style>
</head>
<body>
<div class="container mt-5">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="fas fa-chess-board me-2"></i>All Matches</h2>
    <a href="dashboard.php" class="btn btn-dark"><i class="fas fa-arrow-left me-1"></i>Back to Dashboard</a>
  </div>

  <div class="table-responsive">
    <table class="table table-striped table-bordered">
      <thead class="table-dark">
        <tr>
          <th>ID</th>
          <th>Players</th>
          <th>Entry</th>
          <th>Prize</th>
          <th>Status</th>
          <th>Tournament</th>
          <th>Winner</th>
          <th>Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($matches as $m): ?>
          <tr>
            <td>#<?= $m['id'] ?></td>
            <td><?= htmlspecialchars($m['player1'] ?: 'N/A') ?> vs <?= htmlspecialchars($m['player2'] ?: '...') ?></td>
            <td>₹<?= number_format($m['entry_fee'], 2) ?></td>
            <td>₹<?= number_format($m['entry_fee'] * 2 * 0.95, 2) ?></td>
            <td>
              <?php if ($m['winner_id']): ?>
                <span class="badge badge-status badge-completed">Completed</span>
              <?php elseif ($m['player2_id']): ?>
                <span class="badge badge-status badge-waiting">Playing</span>
              <?php else: ?>
                <span class="badge badge-status badge-waiting">Waiting</span>
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($m['tournament_name'] ?: '-') ?></td>
            <td>
              <?php
              if ($m['winner_id']) {
                echo $m['winner_id'] == $m['player1_id'] ? htmlspecialchars($m['player1']) : htmlspecialchars($m['player2']);
              } else {
                echo '<span class="text-muted">Pending</span>';
              }
              ?>
            </td>
            <td><?= date('d M Y, h:i A', strtotime($m['created_at'])) ?></td>
            <td>
              <?php if (!$m['winner_id'] && $m['player1_id'] && $m['player2_id']): ?>
                <form method="POST" action="declare_winner.php" style="display:inline-block;">
                  <input type="hidden" name="match_id" value="<?= $m['id'] ?>">
                  <select name="winner_id" class="form-select form-select-sm d-inline-block w-auto">
                    <option value="<?= $m['player1_id'] ?>">Player 1</option>
                    <option value="<?= $m['player2_id'] ?>">Player 2</option>
                  </select>
                  <button type="submit" class="btn btn-sm btn-success action-btn"><i class="fas fa-check"></i></button>
                </form>
              <?php endif; ?>
              <form method="POST" action="delete_match.php" style="display:inline-block;">
                <input type="hidden" name="match_id" value="<?= $m['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger action-btn" onclick="return confirm('Are you sure you want to delete this match?')">
                  <i class="fas fa-trash"></i>
                </button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

</body>
</html>
