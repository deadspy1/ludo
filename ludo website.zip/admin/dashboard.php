<?php
session_start();
require '../includes/db.php';
require 'admin_auth.php';
require '../includes/header.php';

$admin_name = $_SESSION['admin_username'] ?? 'Admin';

// Stats
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_balance = $pdo->query("SELECT SUM(balance) FROM users")->fetchColumn() ?: 0;
$total_tournaments = $pdo->query("SELECT COUNT(*) FROM tournaments")->fetchColumn();
$total_completed_matches = $pdo->query("SELECT COUNT(*) FROM matches WHERE winner_id IS NOT NULL")->fetchColumn();
$total_wager = $pdo->query("SELECT SUM(entry_fee * 2) FROM matches WHERE winner_id IS NOT NULL")->fetchColumn() ?: 0;
$admin_earnings = $total_wager * 0.05;
$pending_reviews = $pdo->query("SELECT COUNT(*) FROM matches WHERE (screenshot1 IS NOT NULL OR screenshot2 IS NOT NULL) AND winner_id IS NULL")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard | Super Ludo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    .card-icon {
      font-size: 28px;
      opacity: 0.8;
    }
    .card-body h5 {
      font-weight: 600;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <span class="navbar-brand">🛠 Admin Panel</span>
    <div class="d-flex">
      <span class="navbar-text me-3">Logged in as <strong><?= htmlspecialchars($admin_name) ?></strong></span>
      <a href="admin_logout.php" class="btn btn-outline-light btn-sm">Logout</a>
    </div>
  </div>
</nav>

<div class="container">
  <h2 class="mb-4">Dashboard Overview</h2>

  <div class="row g-4 mb-5">
    <div class="col-md-4">
      <div class="card bg-primary text-white">
        <div class="card-body">
          <h5><i class="fa fa-users card-icon me-2"></i>Total Users</h5>
          <p class="fs-4"><?= $total_users ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card bg-success text-white">
        <div class="card-body">
          <h5><i class="fa fa-wallet card-icon me-2"></i>User Balance Total</h5>
          <p class="fs-4">₹<?= number_format($total_balance, 2) ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card bg-warning text-dark">
        <div class="card-body">
          <h5><i class="fa fa-clock card-icon me-2"></i>Pending Reviews</h5>
          <p class="fs-4"><?= $pending_reviews ?></p>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card bg-info text-white">
        <div class="card-body">
          <h5><i class="fa fa-dice card-icon me-2"></i>Completed Matches</h5>
          <p class="fs-4"><?= $total_completed_matches ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card bg-secondary text-white">
        <div class="card-body">
          <h5><i class="fa fa-money-bill-wave card-icon me-2"></i>Total Wager</h5>
          <p class="fs-4">₹<?= number_format($total_wager, 2) ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card bg-dark text-white">
        <div class="card-body">
          <h5><i class="fa fa-coins card-icon me-2"></i>Admin Earnings</h5>
          <p class="fs-4">₹<?= number_format($admin_earnings, 2) ?></p>
        </div>
      </div>
    </div>
  </div>

  <div class="d-grid gap-3 mb-5">
    <a href="create_tournament.php" class="btn btn-outline-primary btn-lg">➕ Create Tournament</a>
    <a href="tournaments.php" class="btn btn-outline-success btn-lg">📋 View Tournaments</a>
    <a href="review_matches.php" class="btn btn-outline-warning btn-lg">🖼 Review Match Screenshots</a>
    <a href="users.php" class="btn btn-outline-dark btn-lg">👥 Manage Users</a>
    <a href="wallet_requests.php" class="btn btn-outline-dark btn-lg">💸 Wallet Requests</a>
    <a href="wallet_history.php" class="btn btn-outline-dark btn-lg">📜 Wallet History</a>
     <a href="matches.php" class="btn btn-outline-dark btn-lg">📜 Matches</a>
  </div>
</div>

<?php require '../includes/footer.php'; ?>
</body>
</html>
