<?php
require 'admin_auth.php';
require '../includes/db.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $entry_fee = floatval($_POST['entry_fee']);
    $prize = floatval($_POST['prize']);
    $status = $_POST['status'];

    if ($name && $entry_fee >= 0 && $prize >= 0 && in_array($status, ['open', 'closed'])) {
        $stmt = $pdo->prepare("INSERT INTO tournaments (name, entry_fee, prize_pool, status) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$name, $entry_fee, $prize, $status])) {
            $success = "✅ Tournament created successfully.";
        } else {
            $error = "❌ Failed to create tournament.";
        }
    } else {
        $error = "Please fill out all fields correctly.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Create Tournament</title>
</head>
<body>
    <h2>Create Tournament</h2>

    <?php if ($success): ?>
        <p style="color:green"><?= htmlspecialchars($success) ?></p>
    <?php endif; ?>
    <?php if ($error): ?>
        <p style="color:red"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="POST">
        <label>Tournament Name:</label><br>
        <input type="text" name="name" required><br><br>

        <label>Entry Fee (₹):</label><br>
        <input type="number" name="entry_fee" step="0.01" min="0" required><br><br>

        <label>Prize Amount (₹):</label><br>
        <input type="number" name="prize" step="0.01" min="0" required><br><br>

        <label>Status:</label><br>
        <select name="status" required>
            <option value="open">Open</option>
            <option value="closed">Closed</option>
        </select><br><br>

        <button type="submit">Create Tournament</button>
    </form>

    <br><a href="dashboard.php">← Back to Dashboard</a>
</body>
</html>
