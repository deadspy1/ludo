<?php
require '../includes/db.php';
require 'admin_auth.php';

$search = $_GET['search'] ?? '';
$filterQuery = '';
$params = [];

if (!empty($search)) {
    $filterQuery = "AND (u.username LIKE ? OR r.utr_number LIKE ? OR r.upi_id LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Fetch all pending requests with optional search filter
$stmt = $pdo->prepare("
    SELECT r.*, u.username 
    FROM wallet_requests r 
    JOIN users u ON r.user_id = u.id 
    WHERE r.status = 'pending' $filterQuery 
    ORDER BY r.requested_at DESC
");
$stmt->execute($params);
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pending Wallet Requests</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .table thead {
            background-color: #343a40;
            color: white;
        }
        .card {
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card p-4">
        <h2 class="mb-4">Pending Wallet Requests (Add & Withdraw)</h2>

        <!-- Search Form -->
        <form method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Search by username, UTR, or UPI ID..." value="<?= htmlspecialchars($search) ?>">
                <button class="btn btn-primary" type="submit">Search</button>
                <a href="wallet_requests.php" class="btn btn-outline-secondary">Reset</a>
            </div>
        </form>

        <!-- Requests Table -->
        <?php if (empty($requests)): ?>
            <div class="alert alert-info">No pending requests.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Type</th>
                        <th>Amount (₹)</th>
                        <th>UTR / UPI ID</th>
                        <th>Requested At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['username']) ?> (ID: <?= $r['user_id'] ?>)</td>
                        <td><?= ucfirst($r['type']) ?></td>
                        <td>₹<?= number_format($r['amount'], 2) ?></td>
                        <td>
                            <?php if ($r['type'] === 'add'): ?>
                                <?= htmlspecialchars($r['utr_number'] ?? '-') ?>
                            <?php else: ?>
                                <?= htmlspecialchars($r['upi_id'] ?? '-') ?>
                            <?php endif; ?>
                        </td>
                        <td><?= $r['requested_at'] ?></td>
                        <td>
                            <form method="POST" action="process_wallet_request.php" class="d-inline">
                                <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                                <input type="hidden" name="action" value="approve">
                                <button class="btn btn-success btn-sm mb-1">Approve</button>
                            </form>
                            <form method="POST" action="process_wallet_request.php" class="d-inline">
                                <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                                <input type="hidden" name="action" value="reject">
                                <button class="btn btn-danger btn-sm">Reject</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <a href="dashboard.php" class="btn btn-secondary mt-3">&larr; Back to Admin Dashboard</a>
    </div>
</div>
</body>
</html>
