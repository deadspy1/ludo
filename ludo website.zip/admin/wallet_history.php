<?php
require '../includes/db.php';
require 'admin_auth.php';

// Filters (optional: can be extended with dropdowns later)
$type = $_GET['type'] ?? '';
$status = $_GET['status'] ?? '';

$query = "
    SELECT r.*, u.username 
    FROM wallet_requests r 
    JOIN users u ON r.user_id = u.id
    WHERE 1
";
$params = [];

if ($type && in_array($type, ['add', 'withdraw'])) {
    $query .= " AND r.type = ?";
    $params[] = $type;
}

if ($status && in_array($status, ['pending', 'approved', 'rejected'])) {
    $query .= " AND r.status = ?";
    $params[] = $status;
}

$query .= " ORDER BY r.requested_at DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$requests = $stmt->fetchAll();
?>

<h2 class="mb-4">All Wallet Requests</h2>

<!-- Filters -->
<form method="GET" class="row g-3 mb-3">
  <div class="col-md-3">
    <select name="type" class="form-select">
      <option value="">All Types</option>
      <option value="add" <?= $type == 'add' ? 'selected' : '' ?>>Add</option>
      <option value="withdraw" <?= $type == 'withdraw' ? 'selected' : '' ?>>Withdraw</option>
    </select>
  </div>
  <div class="col-md-3">
    <select name="status" class="form-select">
      <option value="">All Statuses</option>
      <option value="pending" <?= $status == 'pending' ? 'selected' : '' ?>>Pending</option>
      <option value="approved" <?= $status == 'approved' ? 'selected' : '' ?>>Approved</option>
      <option value="rejected" <?= $status == 'rejected' ? 'selected' : '' ?>>Rejected</option>
    </select>
  </div>
  <div class="col-md-3">
    <button type="submit" class="btn btn-primary">Filter</button>
    <a href="wallet_history.php" class="btn btn-secondary">Reset</a>
  </div>
</form>

<?php if (empty($requests)): ?>
  <div class="alert alert-warning">No wallet requests found for selected filters.</div>
<?php else: ?>
<table class="table table-bordered table-striped">
  <thead class="table-dark">
    <tr>
      <th>User</th>
      <th>Type</th>
      <th>Amount (₹)</th>
      <th>Status</th>
      <th>Requested At</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($requests as $r): ?>
      <tr>
        <td><?= htmlspecialchars($r['username']) ?> (ID: <?= $r['user_id'] ?>)</td>
        <td><?= ucfirst($r['type']) ?></td>
        <td>₹<?= number_format($r['amount'], 2) ?></td>
        <td>
          <?php
          switch ($r['status']) {
            case 'approved': echo '<span class="text-success">Approved</span>'; break;
            case 'rejected': echo '<span class="text-danger">Rejected</span>'; break;
            default: echo '<span class="text-warning">Pending</span>';
          }
          ?>
        </td>
        <td><?= date('d M Y, h:i A', strtotime($r['requested_at'])) ?></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<?php endif; ?>

<a href="dashboard.php" class="btn btn-secondary mt-3">← Back to Admin Dashboard</a>
