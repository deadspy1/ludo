<?php
session_start();
require '../includes/db.php'; // Adjust path if needed

// 1) Must be “logged in” as admin
if (!isset($_SESSION['admin_id'])) {
    echo "Access denied. (Not logged in)";
    exit;
}

// 2) Double‐check the database flag
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['admin_id']]);
$user = $stmt->fetch();

if (!$user || intval($user['is_admin']) !== 1) {
    echo "Access denied. (Not an admin)";
    exit;
}
