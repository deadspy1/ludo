<?php
require '../includes/db.php';
require 'admin_auth.php';

$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users | Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        table {
            width: 100%;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        th {
            background: #f7f7f7;
            text-align: left;
        }
        td, th {
            padding: 10px;
            vertical-align: middle;
        }
        form {
            display: inline-block;
            margin-right: 5px;
        }
    </style>
</head>
<body class="p-4">

    <h2 class="mb-4">👥 All Users</h2>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Mobile</th>
                <th>Username</th>
                <th>Email</th>
                <th>Balance (₹)</th>
                <th>Status</th>
                <th width="400">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td><?= htmlspecialchars($u['mobile']) ?></td>
                    <td><?= htmlspecialchars($u['username']) ?></td>
                    <td><?= htmlspecialchars($u['email']) ?></td>
                    <td><?= number_format($u['balance'], 2) ?></td>
                    <td>
                        <?= $u['is_banned'] ? '<span class="badge bg-danger">Banned</span>' : '<span class="badge bg-success">Active</span>' ?>
                    </td>
                    <td>
                        <!-- Balance Update -->
                        <form action="update_user.php" method="POST">
                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            <input type="number" step="0.01" name="amount" class="form-control d-inline-block" placeholder="₹ Amount" style="width: 100px;" required>
                            <select name="action" class="form-select d-inline-block" style="width: 90px;">
                                <option value="add">Add</option>
                                <option value="deduct">Deduct</option>
                            </select>
                            <button type="submit" class="btn btn-sm btn-primary">✔</button>
                        </form>

                        <!-- Ban/Unban -->
                        <form action="toggle_ban.php" method="POST">
                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            <button type="submit" class="btn btn-sm <?= $u['is_banned'] ? 'btn-success' : 'btn-warning' ?>">
                                <?= $u['is_banned'] ? 'Unban' : 'Ban' ?>
                            </button>
                        </form>

                        <!-- Delete -->
                        <form action="delete_user.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this user permanently?');">
                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <a href="dashboard.php" class="btn btn-secondary mt-4">← Back to Dashboard</a>

</body>
</html>
