<?php
require '../includes/db.php';
require 'admin_auth.php';

$match_id = $_POST['match_id'] ?? 0;
$winner_id = $_POST['winner_id'] ?? 0;

if ($match_id && $winner_id) {
    $stmt = $pdo->prepare("UPDATE matches SET winner_id = ?, status = 'completed' WHERE id = ?");
    $stmt->execute([$winner_id, $match_id]);

    $stmt = $pdo->prepare("SELECT entry_fee FROM matches WHERE id = ?");
    $stmt->execute([$match_id]);
    $fee = $stmt->fetchColumn();

    $amount = $fee * 2 * 0.95;
    $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
    $stmt->execute([$amount, $winner_id]);

    header("Location: matches.php?winner=updated");
    exit;
}
header("Location: matches.php?error=invalid");
