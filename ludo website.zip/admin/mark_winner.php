<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require '../includes/db.php';
require 'admin_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Access denied.");
}

$match_id = $_POST['match_id'] ?? 0;
$winner_id = $_POST['winner_id'] ?? 0;

if (!$match_id || !$winner_id) {
    die("Invalid data.");
}

// Fetch match
$stmt = $pdo->prepare("
    SELECT m.*, t.prize_pool 
    FROM matches m 
    LEFT JOIN tournaments t ON m.tournament_id = t.id 
    WHERE m.id = ?
");
$stmt->execute([$match_id]);
$match = $stmt->fetch();

if (!$match) {
    die("Match not found.");
}
if ($match['payout_done']) {
    die("Payout already processed for this match.");
}

// Determine payout amount
$payout = 0;
$fee = 0;

if ($match['created_by_user']) {
    $total = $match['entry_fee'] * 2;
    $fee = round($total * 0.05);  // 5% fee
    $payout = $total - $fee;
} else {
    $payout = $match['prize_pool'] ?? 0;
}

// Credit to winner
$stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
$stmt->execute([$payout, $winner_id]);

// Update match
$stmt = $pdo->prepare("
    UPDATE matches 
    SET winner_id = ?, status = 'completed', payout_done = 1 
    WHERE id = ?
");
$stmt->execute([$winner_id, $match_id]);

// Optionally: log payout or show feedback

header("Location: review_matches.php?success=1");
exit;
