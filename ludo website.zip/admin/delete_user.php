<?php
require '../includes/db.php';
require 'admin_auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
    $user_id = intval($_POST['user_id']);

    // Optional: Also delete associated matches, chats, etc. (do with care)
    // $pdo->prepare("DELETE FROM matches WHERE player1_id = ? OR player2_id = ?")->execute([$user_id, $user_id]);
    // $pdo->prepare("DELETE FROM match_chat WHERE user_id = ?")->execute([$user_id]);

    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$user_id]);

    header("Location: users.php?deleted=1");
    exit;
} else {
    die("Invalid access.");
}
