<?php
require '../includes/db.php';
require 'admin_auth.php';

$user_id = intval($_POST['user_id']);
$amount = floatval($_POST['amount']);
$action = $_POST['action'];

if ($amount > 0 && in_array($action, ['add', 'deduct'])) {
    $stmt = $pdo->prepare("UPDATE users SET balance = balance " . ($action == 'add' ? '+' : '-') . " ? WHERE id = ?");
    $stmt->execute([$amount, $user_id]);
}

header("Location: users.php");
exit;
