<?php
require '../includes/db.php';
require 'admin_auth.php';

$user_id = intval($_POST['user_id']);

$stmt = $pdo->prepare("UPDATE users SET is_banned = NOT is_banned WHERE id = ?");
$stmt->execute([$user_id]);

header("Location: users.php");
exit;
