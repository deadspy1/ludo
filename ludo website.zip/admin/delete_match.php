<?php
require '../includes/db.php';
require 'admin_auth.php';

$match_id = $_POST['match_id'] ?? 0;
if ($match_id) {
    $stmt = $pdo->prepare("DELETE FROM matches WHERE id = ?");
    $stmt->execute([$match_id]);
}
header("Location: matches.php?deleted=1");
