<?php
require '../includes/db.php';
require 'admin_auth.php';

$id = $_GET['id'] ?? 0;
$status = $_GET['status'] ?? 'closed';

if ($id && in_array($status, ['open', 'closed'])) {
    $stmt = $pdo->prepare("UPDATE tournaments SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);
}

header("Location: tournaments.php");
exit;
