<?php
require '../includes/db.php';
require 'admin_auth.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$stmt = $pdo->query("SELECT t.*, 
    (SELECT COUNT(*) FROM tournament_players tp WHERE tp.tournament_id = t.id) as players_joined 
    FROM tournaments t ORDER BY created_at DESC");
$tournaments = $stmt->fetchAll();
?>

<h2>All Tournaments</h2>
<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Entry Fee</th>
        <th>Prize</th>
        <th>Status</th>
        <th>Players Joined</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($tournaments as $t): ?>
    <tr>
        <td><?= $t['id'] ?></td>
        <td><?= htmlspecialchars($t['name']) ?></td>
        <td>₹<?= $t['entry_fee'] ?></td>
        <td>₹<?= $t['prize_pool'] ?></td>
        <td><?= ucfirst($t['status']) ?></td>
        <td><?= $t['players_joined'] ?></td>
        <td>
            <?php if ($t['status'] == 'open'): ?>
                <a href="toggle_tournament.php?id=<?= $t['id'] ?>&status=closed">Close</a>
            <?php else: ?>
                <a href="toggle_tournament.php?id=<?= $t['id'] ?>&status=open">Open</a>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<a href="dashboard.php">← Back to Dashboard</a>
