<?php
require 'includes/db.php';
require 'includes/auth.php';

$user_id = $_SESSION['user_id'];
$match_id = intval($_POST['match_id']);

if (!isset($_FILES['screenshot']) || $_FILES['screenshot']['error'] !== UPLOAD_ERR_OK) {
    die("Error uploading screenshot.");
}

// Validate match ownership
$stmt = $pdo->prepare("SELECT * FROM matches WHERE id = ? AND (player1_id = ? OR player2_id = ?)");
$stmt->execute([$match_id, $user_id, $user_id]);
$match = $stmt->fetch();

if (!$match) die("Invalid match.");

$upload_dir = "uploads/";
if (!is_dir($upload_dir)) mkdir($upload_dir);

$filename = uniqid("ss_") . "_" . basename($_FILES['screenshot']['name']);
$filepath = $upload_dir . $filename;

if (move_uploaded_file($_FILES['screenshot']['tmp_name'], $filepath)) {
    $stmt = $pdo->prepare("UPDATE matches SET screenshot_path = ? WHERE id = ?");
    $stmt->execute([$filepath, $match_id]);
    header("Location: waiting_room.php?match_id=$match_id");
} else {
    die("Failed to save file.");
}
