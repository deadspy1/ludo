<?php
session_start();
require 'includes/db.php';

$mobile = $_SESSION['temp_mobile'] ?? '';
$user_id = $_SESSION['user_id'] ?? 0;

if (!$mobile || !$user_id) {
    header("Location: index.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $referral = trim($_POST['referral_code'] ?? '');

    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);

    if ($stmt->rowCount() > 0) {
        $error = "Username already taken.";
    } else {
        $user_referral_code = strtoupper(substr($username, 0, 4)) . rand(1000, 9999);
        $stmt = $pdo->prepare("UPDATE users SET username = ?, referral_code = ?, referred_by = ? WHERE id = ?");
        $stmt->execute([$username, $user_referral_code, $referral ?: null, $user_id]);

        unset($_SESSION['temp_mobile']);
        header("Location: dashboard.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Set Username | Super Ludo</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Fonts & Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: #fff;
      padding: 20px;
    }

    .logo {
      max-height: 40px;
    }

    .top-section {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .setup-box {
      max-width: 400px;
      margin: 30px auto;
      background: #fff;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }

    .setup-box h4 {
      font-weight: 700;
      margin-bottom: 15px;
    }

    .input-group-icon {
      position: relative;
    }

    .input-group-icon i {
      position: absolute;
      top: 50%;
      left: 15px;
      transform: translateY(-50%);
      color: #aaa;
    }

    .input-group-icon input {
      padding-left: 40px;
    }

    .btn-yellow {
      background-color: #FFDD5C;
      color: #000;
      font-weight: 600;
      border: none;
      padding: 12px;
      border-radius: 10px;
      width: 100%;
    }

    .btn-yellow:hover {
      background-color: #f8d23a;
    }

    .dice-img {
      margin: 25px auto 15px;
      width: 60px;
      display: block;
    }

    .legal-text {
      font-size: 0.85rem;
      color: #333;
      text-align: center;
      max-width: 90%;
      margin: auto;
    }

    .legal-text a {
      color: #000;
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="container">
    <div class="top-section mb-3">
      <img src="assets/logo.png" alt="Logo" class="logo">
    </div>

    <div class="setup-box">
      <h4 class="text-center">Create Your Username</h4>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST">
        <div class="mb-3 input-group-icon">
          <i class="fa fa-user"></i>
          <input type="text" name="username" class="form-control" placeholder="Choose a Username" required>
        </div>

        <div class="mb-3 input-group-icon">
          <i class="fa fa-gift"></i>
          <input type="text" name="referral_code" class="form-control" placeholder="Referral Code (optional)">
        </div>

        <button type="submit" class="btn btn-yellow mt-3">Create My Account</button>
      </form>
    </div>

    <img src="assets/dice.gif" class="dice-img" alt="Dice">

    <div class="legal-text mt-2">
      By continuing, I hereby confirm that I am 18 years of age or above and I am not playing from Assam, Telangana, Nagaland, Andhra Pradesh, Sikkim and outside India and I agree to the <a href="terms.php">Terms and Conditions</a> and <a href="privacy.php">Privacy Policy</a>.
    </div>
  </div>

</body>
</html>
