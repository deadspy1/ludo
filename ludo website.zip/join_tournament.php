<?php
session_start();
require 'includes/db.php';
require 'includes/header.php';

$user_id = $_SESSION['user_id'] ?? 0;

// Fetch open admin tournaments
$t_stmt = $pdo->query("SELECT * FROM tournaments WHERE status = 'open' ORDER BY created_at DESC");
$tournaments = $t_stmt->fetchAll();

// Fetch user-hosted open matches (player2 not joined yet)
$m_stmt = $pdo->prepare("
    SELECT m.*, u.username AS host_name 
    FROM matches m
    JOIN users u ON m.player1_id = u.id
    WHERE m.status = 'waiting' 
      AND m.created_by_user = 1 
      AND m.player2_id IS NULL
    ORDER BY m.created_at DESC
");
$m_stmt->execute();
$user_matches = $m_stmt->fetchAll();

// Fetch active VS matches (player2 joined)
$vs_stmt = $pdo->prepare("
    SELECT m.*, 
           u1.username AS host_name, 
           u2.username AS opponent_name 
    FROM matches m
    JOIN users u1 ON m.player1_id = u1.id
    JOIN users u2 ON m.player2_id = u2.id
    WHERE m.status = 'waiting' 
      AND m.created_by_user = 1 
    ORDER BY m.created_at DESC
");
$vs_stmt->execute();
$vs_matches = $vs_stmt->fetchAll();
?>

<!-- Bootstrap CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
    body { background: #f8f9fa; }
    .match-box {
        background: #fff;
        border-radius: 12px;
        padding: 15px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        margin-bottom: 15px;
    }
    .match-box.user-hosted {
        border: 2px solid #ffca28;
    }
    .match-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .match-label {
        font-size: 14px;
        color: #555;
    }
    .match-value {
        font-size: 16px;
        font-weight: bold;
    }
    .play-btn {
        background: #ffc107;
        border: none;
        padding: 6px 20px;
        border-radius: 30px;
        font-weight: bold;
        color: #000;
    }
    .vs-text {
        text-align: center;
        font-weight: bold;
        font-size: 15px;
        color: #555;
    }
</style>
  <div class="container">
    <div class="top-section mb-3">
      <img src="assets/logo.png" alt="Logo" class="logo">
    </div>
<div class="container py-4">
    <h2 class="mb-4">Available Matches</h2>

    <!-- 🔍 Search + Set Match -->
    <div class="input-group mb-4">
        <input type="number" id="searchInput" class="form-control" placeholder="Search by Entry Amount...">
        <button class="btn btn-outline-primary" id="setMatchBtn" style="display:none;">Set Match</button>
    </div>

    <div id="matchesList">
        <!-- 🟢 User-Hosted Matches -->
        <?php foreach ($user_matches as $m): ?>
            <div class="match-box user-hosted" data-entry="<?= $m['entry_fee'] ?>">
                <div class="match-info mb-2">
                    <div>
                        <div class="match-label">Prize</div>
                        <div class="match-value text-success">
                            ₹<?= number_format($m['entry_fee'] * 2 * 0.95, 2) ?>
                        </div>
                    </div>
                    <div>
                        <div class="match-label">Entry</div>
                        <div class="match-value text-danger">₹<?= $m['entry_fee'] ?></div>
                    </div>
                    <div>
                        <form method="POST" action="join_match.php">
                            <input type="hidden" name="match_id" value="<?= $m['id'] ?>">
                            <button type="submit" class="play-btn">PLAY</button>
                        </form>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-2">
                    <div class="small text-muted">🏆 Open Challenge</div>
                    <div class="text-muted small">By <?= htmlspecialchars($m['host_name']) ?></div>
                </div>
            </div>
        <?php endforeach; ?>

        <!-- 🟡 Admin Tournaments -->
        <?php foreach ($tournaments as $t): ?>
            <div class="match-box" data-entry="<?= $t['entry_fee'] ?>">
                <div class="match-info mb-2">
                    <div>
                        <div class="match-label">Prize</div>
                        <div class="match-value text-success">₹<?= $t['prize'] ?? $t['prize_pool'] ?></div>
                    </div>
                    <div>
                        <div class="match-label">Entry</div>
                        <div class="match-value text-danger">₹<?= $t['entry_fee'] ?></div>
                    </div>
                    <div>
                        <form method="POST" action="process_join.php">
                            <input type="hidden" name="tournament_id" value="<?= $t['id'] ?>">
                            <button type="submit" class="play-btn">PLAY</button>
                        </form>
                    </div>
                </div>
                <div class="text-muted small">Admin Tournament</div>
            </div>
        <?php endforeach; ?>

        <!-- ⚔️ Active VS Matches -->
        <?php if (!empty($vs_matches)): ?>
            <h5 class="mt-4">Ongoing Matches</h5>
            <?php foreach ($vs_matches as $v): ?>
                <div class="match-box" data-entry="<?= $v['entry_fee'] ?>">
                    <div class="match-info mb-2">
                        <div>
                            <div class="match-label">Prize</div>
                            <div class="match-value text-success">
                                ₹<?= number_format($v['entry_fee'] * 2 * 0.95, 2) ?>
                            </div>
                        </div>
                        <div>
                            <div class="match-label">Entry</div>
                            <div class="match-value text-danger">₹<?= $v['entry_fee'] ?></div>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-secondary">In Progress</span>
                        </div>
                    </div>
                    <div class="vs-text">
                        <?= htmlspecialchars($v['host_name']) ?> <span class="text-warning mx-2">VS</span> <?= htmlspecialchars($v['opponent_name']) ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <a href="dashboard.php" class="btn btn-secondary mt-4 w-100">← Back to Dashboard</a>
</div>

<!-- JS: Search & Set Match -->
<script>
const input = document.getElementById("searchInput");
const allMatches = document.querySelectorAll(".match-box");
const setMatchBtn = document.getElementById("setMatchBtn");

input.addEventListener("input", function () {
    const value = this.value.trim();
    let visibleCount = 0;

    allMatches.forEach(box => {
        const fee = parseFloat(box.getAttribute("data-entry"));
        if (!value || fee == value) {
            box.style.display = "block";
            visibleCount++;
        } else {
            box.style.display = "none";
        }
    });

    setMatchBtn.style.display = (value && visibleCount === 0) ? "inline-block" : "none";
});

setMatchBtn.addEventListener("click", function () {
    const value = input.value.trim();
    if (value && !isNaN(value)) {
        window.location.href = `create_user_match.php?entry=${value}`;
    }
});
</script>

<?php require 'includes/footer.php'; ?>
