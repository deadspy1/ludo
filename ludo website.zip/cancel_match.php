<?php
require 'includes/db.php';
session_start();

header('Content-Type: application/json');

$user_id = $_SESSION['user_id'] ?? 0;
$match_id = $_GET['match_id'] ?? 0;

if (!$user_id || !$match_id) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM matches WHERE id = ?");
$stmt->execute([$match_id]);
$match = $stmt->fetch();

if (!$match || $match['player2_id']) {
    // Match already has opponent or doesn't exist
    echo json_encode(['success' => false, 'error' => 'Match already joined or not found']);
    exit;
}

// Refund entry fee
$stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
$stmt->execute([$match['entry_fee'], $user_id]);

// Delete match
$stmt = $pdo->prepare("DELETE FROM matches WHERE id = ?");
$stmt->execute([$match_id]);

unset($_SESSION['match_id']);
echo json_encode(['success' => true]);
exit;
