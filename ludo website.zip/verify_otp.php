<?php
session_start();
require 'includes/db.php';

$mobile = $_SESSION['otp_mobile'] ?? '';
$user_id = $_SESSION['otp_user_id'] ?? 0;

if (!$mobile || !$user_id) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';
$otp_timer_seconds = 30;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['resend'])) {
        $newOtp = rand(100000, 999999);
        $now = date('Y-m-d H:i:s');

        $stmt = $pdo->prepare("UPDATE users SET otp_code = ?, otp_created_at = ? WHERE id = ?");
        $stmt->execute([$newOtp, $now, $user_id]);

        $message = "Welcome to the nxlgames powered by SMSINDIAHUB. Your new OTP is $newOtp";

        $params = [
            'APIKey' => 'OolKGter4ESNowf7s3756w',
            'msisdn' => '91' . $mobile,
            'sid'    => 'SMSHUB',
            'msg'    => $message,
            'fl'     => '0',
            'gwid'   => '2'
        ];

        $smsUrl = "http://cloud.smsindiahub.in/vendorsms/pushsms.aspx?" . http_build_query($params);
        file_get_contents($smsUrl);

        $success = "OTP has been resent to $mobile.";
    } elseif (isset($_POST['otp'])) {
        $otp = trim($_POST['otp']);

        $stmt = $pdo->prepare("SELECT id FROM users WHERE mobile = ? AND otp_code = ?");
        $stmt->execute([$mobile, $otp]);
        $user = $stmt->fetch();

        if ($user) {
            $pdo->prepare("UPDATE users SET otp_code = NULL WHERE id = ?")->execute([$user['id']]);

            $_SESSION['user_id'] = $user['id'];
            unset($_SESSION['otp_mobile'], $_SESSION['otp_user_id']);

            $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
            $stmt->execute([$user['id']]);
            $username = $stmt->fetchColumn();

            if (!$username) {
                $_SESSION['temp_mobile'] = $mobile;
                header("Location: set_username.php");
            } else {
                header("Location: dashboard.php");
            }
            exit;
        } else {
            $error = "Invalid OTP. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enter OTP | Super Ludo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Inter Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a2d4f46d83.js" crossorigin="anonymous"></script>
    
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #fff;
            text-align: center;
            padding: 20px;
        }

        .logo {
            max-height: 40px;
            margin-top: 10px;
        }

        .top-icons {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .top-icons i {
            margin-left: 15px;
        }

        .otp-box {
            width: 100%;
            max-width: 400px;
            margin: 20px auto;
        }

        .otp-input {
            font-size: 20px;
            padding: 12px 15px;
            border-radius: 10px;
            border: 2px solid #ccc;
            width: 100%;
        }

        .resend-text {
            color: red;
            font-weight: 600;
            font-size: 14px;
            margin-top: 10px;
        }

        .btn-yellow {
            background-color: #FFDD5C;
            color: #000;
            font-weight: 600;
            border: none;
            width: 100%;
            padding: 12px;
            border-radius: 10px;
        }

        .btn-yellow:hover {
            background-color: #f8d23a;
        }

        .change-number {
            margin-top: 15px;
            font-weight: bold;
            color: #3a2e00;
            text-decoration: none;
            display: inline-block;
        }

        .dice-img {
            margin: 20px auto 10px;
            width: 60px;
        }

        .legal-text {
            font-size: 0.85rem;
            color: #333;
            margin-top: 20px;
            max-width: 90%;
            margin-left: auto;
            margin-right: auto;
        }

        .legal-text a {
            color: #000;
            text-decoration: underline;
        }
    </style>
</head>
<body>

     <div class="container text-center mt-4">
        <div class="header-logo">
            <img src="assets/logo.png" alt="Super Ludo Logo" class="logo">
        </div><br/><br/>

        <!-- Title -->
        <h4 class="fw-bold mt-3">Enter OTP</h4>
        <p class="text-muted mb-4">Please enter the 6 Digit OTP</p>

        <!-- OTP Form -->
        <div class="otp-box">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <form method="POST">
                <input type="text" name="otp" maxlength="6" class="otp-input" placeholder="6-Digit OTP" required>
                <button type="submit" class="btn btn-yellow mt-3">DONE</button>
            </form>

            <form method="POST">
                <input type="hidden" name="resend" value="1">
                <div class="resend-text" id="resend-timer">Resend OTP in <span id="timer"><?= $otp_timer_seconds ?></span></div>
                <button id="resend-btn" class="btn btn-link text-danger d-none" type="submit">Resend OTP</button>
            </form>

            <a href="index.php" class="change-number mt-3 d-block"><i class="fas fa-arrow-left me-1"></i>CHANGE NUMBER</a>
        </div>

        <img src="assets/dice.gif" class="dice-img" alt="Dice">

        <div class="legal-text">
            By continuing, I hereby confirm that I am 18 years of age or above and I am not playing from Assam, Telangana, Nagaland, Andhra Pradesh, Sikkim and outside India and I agree to the <a href="terms.php">Terms and Conditions</a> and <a href="privacy.php">Privacy Policy</a>.
        </div>
    </div>

    <!-- Countdown Timer Script -->
    <script>
        let seconds = <?= $otp_timer_seconds ?>;
        const timerSpan = document.getElementById("timer");
        const resendBtn = document.getElementById("resend-btn");

        const countdown = setInterval(() => {
            if (seconds > 0) {
                seconds--;
                timerSpan.innerText = seconds.toString().padStart(2, '0');
            } else {
                clearInterval(countdown);
                document.getElementById("resend-timer").classList.add("d-none");
                resendBtn.classList.remove("d-none");
            }
        }, 1000);
    </script>

</body>
</html>
