<?php
session_start();
require 'includes/db.php';
require 'includes/header.php';

$user_id = $_SESSION['user_id'] ?? 0;

// Fetch all open matches
$stmt = $pdo->query("
    SELECT m.*, 
           u1.username AS player1_name, 
           u2.username AS player2_name
    FROM matches m
    LEFT JOIN users u1 ON m.player1_id = u1.id
    LEFT JOIN users u2 ON m.player2_id = u2.id
    WHERE m.status = 'waiting'
    ORDER BY m.created_by_user DESC, m.created_at DESC
");
$matches = $stmt->fetchAll();
?>

<div class="container py-4">
  <h2>Available Tournaments & Matches</h2>

  <!-- 🔍 Live Search -->
  <div class="mb-4" style="max-width: 300px;">
    <input type="text" id="searchAmount" class="form-control" placeholder="Search by amount (e.g. 100)">
  </div>

  <?php if (empty($matches)): ?>
    <div class="alert alert-info">No matches available. Please check back later.</div>
  <?php endif; ?>

  <div class="row g-4">
    <?php foreach ($matches as $match): ?>
      <div class="col-md-6 matchCard" data-amount="<?= $match['entry_fee'] ?>">
        <div class="card shadow-sm border <?= $match['created_by_user'] ? 'border-success' : 'border-primary' ?>">
          <div class="card-body">
            <h5 class="card-title">
              ₹<?= $match['entry_fee'] ?> Match 
              <span class="badge <?= $match['created_by_user'] ? 'bg-success' : 'bg-primary' ?>">
                <?= $match['created_by_user'] ? 'User Match' : 'Admin Tournament' ?>
              </span>
            </h5>
            <p class="mb-1">Host: <strong><?= htmlspecialchars($match['player1_name']) ?></strong></p>
            <p class="mb-1">Created: <?= date("d M Y, h:i A", strtotime($match['created_at'])) ?></p>

            <?php if ($user_id == $match['player1_id']): ?>
              <div class="alert alert-warning mb-2">You created this match.</div>
              <?php if (!$match['player2_id']): ?>
                <form action="cancel_match.php" method="POST">
                  <input type="hidden" name="match_id" value="<?= $match['id'] ?>">
                  <button type="submit" class="btn btn-outline-danger btn-sm">Cancel Match</button>
                </form>
              <?php endif; ?>
            <?php elseif ($match['player2_id']): ?>
              <button class="btn btn-secondary" disabled>Already Full</button>
            <?php else: ?>
              <form action="join_match.php" method="POST">
                <input type="hidden" name="match_id" value="<?= $match['id'] ?>">
                <button type="submit" class="btn btn-primary">Join Match</button>
              </form>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<?php require 'includes/footer.php'; ?>

<!-- ✅ Live Filter Script -->
<script>
document.getElementById("searchAmount").addEventListener("input", function () {
  const input = this.value.trim();
  const cards = document.querySelectorAll(".matchCard");

  cards.forEach(card => {
    const fee = card.getAttribute("data-amount");
    if (input === "" || fee.startsWith(input)) {
      card.style.display = "block";
    } else {
      card.style.display = "none";
    }
  });
});
</script>
