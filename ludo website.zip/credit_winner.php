<?php
require 'includes/db.php';
require 'includes/auth.php';

$match_id = intval($_POST['match_id'] ?? 0);

// Get match info
$stmt = $pdo->prepare("SELECT * FROM matches WHERE id = ?");
$stmt->execute([$match_id]);
$match = $stmt->fetch();

if (!$match || !$match['winner_id']) {
    die("Invalid match or winner not set.");
}

// Set prize value (can be dynamic later)
$prize_amount = 100.00;

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
    $stmt->execute([$prize_amount, $match['winner_id']]);

    // Optional: mark match as "paid"
    $stmt = $pdo->prepare("UPDATE matches SET status = 'completed' WHERE id = ?");
    $stmt->execute([$match_id]);

    $pdo->commit();
    echo "Prize credited successfully!";
} catch (Exception $e) {
    $pdo->rollBack();
    echo "Failed to credit prize.";
}
