<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Privacy Policy - SuperLudo.online</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f1f3f5;
      color: #333;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 900px;
      margin: 40px auto;
      background: #fff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 2px 16px rgba(0,0,0,0.1);
    }
    h1 {
      color: #1e1e1e;
      text-align: center;
    }
    h2 {
      margin-top: 30px;
      color: #222;
    }
    p, li {
      line-height: 1.7;
      margin: 10px 0;
    }
    ul {
      padding-left: 20px;
    }
    footer {
      text-align: center;
      margin-top: 50px;
      color: #777;
    }
    a {
      color: #c62828;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Privacy Policy</h1>
    <p><strong>Effective Date:</strong> [10/05/2025]</p>

    <p>SuperLudo.online ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy outlines how we handle your information when you use our website and services.</p>

    <h2>1. Information We Collect</h2>
    <ul>
      <li><strong>Personal Info:</strong> Name, email, phone number, DOB, payment data, etc.</li>
      <li><strong>Non-personal Info:</strong> IP address, browser, device, etc.</li>
    </ul>

    <h2>2. Use of Your Information</h2>
    <p>We use your information to operate our services, process payments, improve functionality, and communicate updates.</p>

    <h2>3. Data Sharing</h2>
    <p>We only share data with trusted third parties like payment processors and KYC services, and never sell your data.</p>

    <h2>4. Security</h2>
    <p>We follow industry standards to secure your information but no method is 100% foolproof.</p>

    <h2>5. Cookies</h2>
    <p>We use cookies for analytics and improving user experience.</p>

    <h2>6. Children</h2>
    <p>Our service is not for users under 18 years of age.</p>

    <h2>7. Changes</h2>
    <p>We may update this policy and changes will be posted here with the new effective date.</p>

    <h2>8. Contact Us</h2>
    <p>Email: <a href="mailto:support@superludo.online">support@superludo.online</a></p>

    <footer>&copy; 2025 SuperLudo.online</footer>
  </div>
</body>
</html>
