<?php
session_start();
require 'includes/db.php';
require 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';
$step = 1;
$amount = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['step']) && $_POST['step'] == 2) {
        $amount = floatval($_POST['amount'] ?? 0);
        $utr = trim($_POST['utr'] ?? '');

        if ($amount > 0 && !empty($utr)) {
            $stmt = $pdo->prepare("INSERT INTO wallet_requests (user_id, type, amount, utr_number, status) VALUES (?, 'add', ?, ?, 'pending')");
            $stmt->execute([$user_id, $amount, $utr]);
            $message = "Fund request for ₹$amount submitted with UTR: $utr. Admin will verify it shortly.";
        } else {
            $message = "Please enter both a valid amount and UTR number.";
            $step = 2;
        }
    } else {
        $amount = floatval($_POST['amount'] ?? 0);
        if ($amount > 0) {
            $step = 2;
        } else {
            $message = "Please enter a valid amount.";
        }
    }
}
?>

<!-- Bootstrap + FontAwesome -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

<style>
body {
    background: #f8f9fa;
    font-family: 'Poppins', sans-serif;
}
h2, h4 {
    font-weight: 600;
}
label {
    font-weight: 500;
}
.btn {
    font-weight: 600;
}
.container {
    max-width: 480px;
    margin: 30px auto;
    background: #fff;
    padding: 25px;
    border-radius: 16px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}
a {
    color: inherit;
    text-decoration: none;
}
a:hover {
    color: #ffca28;
}
.copy-btn {
    background: #ffca28;
    border: none;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 14px;
    margin-left: 8px;
    font-weight: 600;
}
.navbar-bottom {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 60px;
    background-color: #fff;
    display: flex;
    justify-content: space-around;
    align-items: center;
    border-top: 1px solid #ddd;
    z-index: 1000;
}
.navbar-bottom a {
    color: #555;
    text-decoration: none;
    font-size: 13px;
    display: flex;
    flex-direction: column;
    align-items: center;
}
.navbar-bottom a.active {
    color: #ffca28;
    font-weight: bold;
}
.navbar-bottom .center-btn {
    background-color: #ffca28;
    color: black;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    margin-top: -30px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}
.navbar-bottom a i {
    font-size: 18px;
}
    .balance-box {
      position: absolute;
      top: 20px;
      right: 20px;
      background: #fff;
      border: 2px solid #FFDD5C;
      padding: 6px 16px;
      border-radius: 50px;
      font-weight: 600;
      font-size: 14px;
      color: #000;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      z-index: 1000;
    }
</style>
<div class="container text-center mt-4">
        <div class="header-logo">
            <img src="assets/logo.png" alt="Super Ludo Logo" class="logo">
        </div>

<div class="container">
    <h2 class="text-center mb-4">Add Funds</h2>

    <?php if ($message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <?php if ($step === 1): ?>
        <form method="POST">
            <input type="hidden" name="step" value="1">
            <div class="mb-3">
                <label class="form-label">Amount (₹)</label>
                <input type="number" name="amount" class="form-control" min="1" required>
            </div>
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-warning w-100 me-2">Proceed to Payment</button>
                <a href="dashboard.php" class="btn btn-outline-secondary">Back</a>
            </div>
        </form>

    <?php elseif ($step === 2): ?>
        <div class="text-center">
            <h4 class="mb-2">Scan & Pay</h4>
            <p><strong>UPI ID:</strong> <code id="upi-id">paytm.s1e1kin@pty</code>
                <button onclick="copyUPI()" class="copy-btn">Copy</button>
            </p>
            <img src="uploads/11.png" alt="QR Code" class="img-fluid mb-3" style="max-width: 200px;">
        </div>

        <form method="POST">
            <input type="hidden" name="step" value="2">
            <input type="hidden" name="amount" value="<?= htmlspecialchars($amount) ?>">
            <div class="mb-3">
                <label class="form-label">Enter UTR/Transaction ID</label>
                <input type="text" name="utr" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-warning w-100 me-2">Submit Request</button>
        </form>

        <script>
            function copyUPI() {
                navigator.clipboard.writeText("paytm.s1e1kin@pty");
                alert("UPI ID copied to clipboard!");
            }
        </script>
    <?php endif; ?>
</div>

<!-- Bottom Navbar -->
<div class="navbar-bottom">
    <a href="join_tournament.php">
        <i class="fa-solid fa-dice"></i>
        <span>Play</span>
    </a>
    <a href="referrals.php">
        <i class="fa-solid fa-users"></i>
        <span>Referral</span>
    </a>
    <a href="add_funds.php" class="center-btn">
        <i class="fa-solid fa-indian-rupee-sign"></i>
    </a>
    <a href="wallet.php">
        <i class="fa-solid fa-wallet"></i>
        <span>Wallet</span>
    </a>
    <a href="profile.php">
        <i class="fa-solid fa-user"></i>
        <span>Profile</span>
    </a>
</div>

<?php require 'includes/footer.php'; ?>
