<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require 'includes/db.php';

$user_id = $_SESSION['user_id'] ?? 0;
$match_id = $_SESSION['match_id'] ?? 0;

if (!$user_id || !$match_id) {
    die("Access denied.");
}

$stmt = $pdo->prepare("SELECT m.*, u1.username AS player1_name, u2.username AS player2_name FROM matches m LEFT JOIN users u1 ON m.player1_id = u1.id LEFT JOIN users u2 ON m.player2_id = u2.id WHERE m.id = ?");
$stmt->execute([$match_id]);
$match = $stmt->fetch();

if (!$match) {
    unset($_SESSION['match_id']);
    header("Location: dashboard.php?expired=1");
    exit;
}

// Handle manual cancel if no opponent has joined
if (isset($_GET['cancel']) && empty($match['player2_id'])) {
    $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
    $stmt->execute([$match['entry_fee'], $user_id]);

    $stmt = $pdo->prepare("DELETE FROM matches WHERE id = ?");
    $stmt->execute([$match_id]);

    unset($_SESSION['match_id']);
    header("Location: dashboard.php?cancelled=1");
    exit;
}


// Variables
$is_player1 = $user_id == $match['player1_id'];
$is_user_hosted = $match['created_by_user'] == 1;
$is_host = $match['host_id'] == $user_id;
$opponent_joined = isset($match['player2_id']) && $match['player2_id'];
$opponent_session_key = "match_{$match_id}_opponent_seen";
$new_opponent = $opponent_joined && empty($_SESSION[$opponent_session_key]);
if ($new_opponent) $_SESSION[$opponent_session_key] = true;

// Update last active match
$update = $pdo->prepare("UPDATE users SET last_active_match_id = ? WHERE id = ?");
$update->execute([$match_id, $user_id]);

// Handle Ludo code submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ludo_code'])) {
    $code = trim($_POST['ludo_code']);
    if (!empty($code) && strlen($code) === 8 && !$match['ludo_code']) {
        if (($is_user_hosted && $is_player1) || !$is_user_hosted) {
            $stmt = $pdo->prepare("UPDATE matches SET ludo_code = ?, host_id = ? WHERE id = ?");
            $stmt->execute([$code, $user_id, $match_id]);
            header("Location: waiting_area.php");
            exit;
        }
    }
}

?>

<!-- HTML HEAD -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Waiting Area</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
  <meta http-equiv="refresh" content="35">
  
   <style>
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      font-family: 'Outfit', sans-serif;
      background-color: #ffcc29;
      color: #111;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 30px 16px;
    }
a { text-decoration: none; } 


    .logo {
      font-size: 36px;
      font-weight: 700;
      color: #0077cc;
      margin-bottom: 20px;
    }

    .title {
      font-size: 36px;
      font-weight: bold;
      margin-bottom: 30px;
      color: white;
      text-shadow: 1px 1px 2px #00000033;
    }

    .vs-box {
      background: white;
      border-radius: 12px;
      padding: 20px 30px;
      box-shadow: 0 6px 16px rgba(0,0,0,0.1);
      display: flex;
      align-items: center;
      justify-content: space-around;
      max-width: 480px;
      width: 100%;
      margin-bottom: 30px;
      position: relative;
    }

    .player {
      font-size: 18px;
      font-weight: 600;
    }

    .vs {
      font-size: 28px;
      font-weight: 900;
      background: #002244;
      color: white;
      padding: 10px 20px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }

    .timer {
      font-size: 36px;
      font-weight: bold;
      background: #002244;
      color: white;
      padding: 10px 30px;
      border-radius: 12px;
      margin-bottom: 20px;
    }

    .btn {
      padding: 12px 24px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      margin-top: 10px;
    }

    .btn-cancel {
      background-color: #e63946;
      color: white;
    }

    .match-started {
      margin-top: 15px;
      color: #008000;
      font-weight: 600;
      display: flex;
      align-items: center;
    }

    .match-started::before {
      content: "✔";
      margin-right: 8px;
    }

    .match-details {
      background: white;
      border-radius: 12px;
      padding: 20px;
      margin-top: 30px;
      max-width: 480px;
      width: 100%;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .match-details h3 {
      margin-top: 0;
      margin-bottom: 16px;
      text-align: center;
    }

    .match-info {
      display: flex;
      justify-content: space-between;
      font-size: 16px;
      font-weight: 600;
    }

    .match-info div {
      flex: 1;
      text-align: center;
    }
    
    
    .section-card {
  background: #ffffff;
  border-radius: 16px;
  padding: 20px;
  margin: 20px 0;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.section-title {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 16px;
  color: #1f2937;
}

.code-display {
  display: flex;
  align-items: center;
  margin-bottom: 12px;
}

.code-text {
  background-color: #1e3a8a;
  color: white;
  padding: 10px 16px;
  border-radius: 8px 0 0 8px;
  font-weight: bold;
  font-size: 16px;
}

.btn-copy {
  background-color: #f3f4f6;
  color: #1e3a8a;
  border: none;
  padding: 10px 16px;
  border-radius: 0 8px 8px 0;
  cursor: pointer;
  font-weight: bold;
}

.btn-submit-result {
  background-color: #1e3a8a;
  color: white;
  padding: 10px 20px;
  border-radius: 10px;
  border: none;
  margin-top: 10px;
  cursor: pointer;
  font-weight: bold;
}

.code-label {
  display: block;
  margin-bottom: 8px;
  font-weight: 500;
}

.code-input {
  padding: 10px;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  margin-right: 10px;
}

.waiting-msg {
  font-style: italic;
  color: #6b7280;
}

.host-info {
  margin-top: 8px;
  font-size: 14px;
  color: #4b5563;
}

.chat-box {
  max-height: 200px;
  overflow-y: auto;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 10px;
  background-color: #f9fafb;
  margin-bottom: 12px;
}

.chat-msg {
  margin-bottom: 8px;
  font-size: 14px;
}

.chat-me {
  text-align: right;
  color: #1e40af;
}

.chat-other {
  text-align: left;
  color: #111827;
}

.chat-form {
  display: flex;
  align-items: center;
  gap: 10px;
}

.chat-input {
  flex: 1;
  padding: 10px 12px;
  border-radius: 10px;
  border: 1px solid #d1d5db;
  font-size: 14px;
}

.btn-send {
  background-color: #1e3a8a;
  color: white;
  padding: 10px 16px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  font-weight: bold;
}

    
  </style>
</head>
<body>

<!-- MAIN HTML -->
<div class="logo">
      <img src="assets/logo_wait.png" alt="Logo" class="logo">
    </div>
<div class="title">Waiting Area</div>

 
  
    
    <div class="vs-box">

                
                <div class="player"><?= htmlspecialchars($is_player1 ? $match['player1_name'] : $match['player2_name']) ?></div>
                <?php if ($match['host_id'] == $user_id): ?>
                    <span class="badge badge-host">Host</span>
                <?php endif; ?>
            
    
     <div class="vs">VS</div>

    

                <?php if ($match['player2_id']): ?>
                    <div class="player"><?= htmlspecialchars(!$is_player1 ? $match['player1_name'] : $match['player2_name']) ?></div>
                    <?php if ($match['host_id'] && $match['host_id'] != $user_id): ?>
                        <span class="badge badge-host">Host</span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="text-muted <?= $new_opponent ? 'glow' : '' ?>">Waiting...</span>
                <?php endif; ?>
        
    </div>
  
  <div id="timer" class="timer">05:00</div>
        <?php if (!$match['player2_id']): ?>
<button class="btn btn-cancel">
  <a href="?cancel=1" id="cancelBtn"><span style="color:#fff;">Cancel Match</span></a></button>
  

        <?php endif; ?>
  <br/>
  <span style="color:red;">Note: कृपया करके जितने वाला व्यक्ति अपना स्क्रीनशॉट सबमिट करे अन्यथा आपकी जीत नहीं मानी जाएगी। </span>
  
  
    <div class="match-details">
    <h3>Match Details</h3>
    <div class="match-info">
      <div>💰 Entry Fee<br><span style="color:#d00000;">₹<?= number_format($match['entry_fee'], 2) ?></span></div>
      <div>🏆 Prize<br><span style="color:#28a745;">₹<?= number_format($match['entry_fee'] * 2 * 0.95, 2) ?></span></div>
      <div>#️⃣ Match ID<br><strong><?= $match['id'] ?></strong></div>
    </div>
  </div>
   

     <!-- Ludo Code Section -->
<?php if ($match['player1_id'] && $match['player2_id']): ?>
  <div class="match-details">
    <h3 class="section-title">Ludo King Code</h3>
    
    <?php if ($match['ludo_code']): ?>
      <div class="code-display">
        <div class="code-text" id="codeText"><?= htmlspecialchars($match['ludo_code']) ?></div>
        <button class="btn-copy" onclick="copyCode()">Copy</button>
      </div>
      <p class="host-info">Host: <span style="color:#d00000;"><strong><?= $match['host_id'] == $match['player1_id'] ? $match['player1_name'] : $match['player2_name'] ?></strong></span></p>
      <a href="submit_result.php" class="btn-submit-result">Submit Result</a>
    
    <?php elseif (($is_user_hosted && $is_player1) || !$is_user_hosted): ?>
      <form method="POST" class="form-inline">
        <label class="code-label">Enter Ludo Code:</label>
        <input type="text" name="ludo_code" maxlength="8" minlength="8" required class="code-input">
        <button type="submit" class="btn-submit-result">Submit Code</button>
      </form>
    <?php else: ?>
      <div class="waiting-msg">Waiting for host to enter Ludo code...</div>
    <?php endif; ?>
  </div>
<?php endif; ?>

<!-- Chat Section -->
<div class="match-details">
  <h3 class="section-title">Chat with Opponent</h3>
  <div class="chat-box">
    <?php
    $chatStmt = $pdo->prepare("SELECT c.*, u.username FROM match_chat c JOIN users u ON c.user_id = u.id WHERE match_id = ? ORDER BY created_at DESC LIMIT 20");
    $chatStmt->execute([$match_id]);
    $chat = array_reverse($chatStmt->fetchAll());
    foreach ($chat as $msg):
    ?>
      <div class="chat-msg <?= $msg['user_id'] == $user_id ? 'chat-me' : 'chat-other' ?>">
        <strong><?= htmlspecialchars($msg['username']) ?>:</strong> <?= htmlspecialchars($msg['message']) ?>
      </div>
    <?php endforeach; ?>
  </div>
  <form action="chat_post.php" method="POST" class="chat-form">
    <input type="hidden" name="match_id" value="<?= $match_id ?>">
    <input type="text" name="message" class="chat-input" placeholder="Type a message..." required>
    <button type="submit" class="btn-send">Send</button>
  </form>
</div>

<?php require 'includes/footer.php'; ?>

<!-- JS Scripts -->
<script>
const matchId = "<?= $match_id ?>";
const timerKey = "match_" + matchId + "_timer";
let endTime = localStorage.getItem(timerKey);
if (!endTime) {
    endTime = Date.now() + 180000; // 3 minutes
    localStorage.setItem(timerKey, endTime);
}

function updateTimer() {
    const now = Date.now();
    const remaining = Math.max(0, Math.floor((endTime - now) / 1000));
    const m = Math.floor(remaining / 60);
    const s = remaining % 60;
    document.getElementById("timer").textContent = `${m}:${s.toString().padStart(2, '0')}`;
    if (remaining > 0) {
        setTimeout(updateTimer, 1000);
    } else {
        document.getElementById("timer").textContent = "Match Start !!";
        fetch("check_match_status.php?match_id=<?= $match_id ?>")
            .then(res => res.json())
            .then(data => {
                if (!data.joined) autoCancelMatch();
            });
    }
}
updateTimer();

function autoCancelMatch() {
    fetch("cancel_match.php?match_id=<?= $match_id ?>")
        .then(res => res.json())
        .then(data => {
            if (data.success) window.location.href = "dashboard.php?cancelled=1";
            else document.getElementById("cancelMatch").style.display = "block";
        })
        .catch(() => document.getElementById("cancelMatch").style.display = "block");
}

function copyCode() {
    const text = document.getElementById("codeText").innerText;
    navigator.clipboard.writeText(text);
    alert("Code copied to clipboard!");
}
setInterval(() => {
  fetch("check_match_status.php?match_id=<?= $match_id ?>")
    .then(res => res.json())
    .then(data => {
      if (data.joined) {
        const cancelBtn = document.getElementById("cancelBtn");
        const matchLabel = document.getElementById("matchStartedLabel");

        if (cancelBtn) cancelBtn.classList.add("d-none");
        if (matchLabel) matchLabel.classList.remove("d-none");

        if (!<?= json_encode($match['player2_id']) ?>) {
          location.reload();
        }
      }
    });

  // Optional: check for ludo code if needed
  fetch("check_ludo_code.php?match_id=<?= $match_id ?>")
    .then(res => res.json())
    .then(data => {
      if (data.code_entered && !<?= json_encode($match['ludo_code']) ?>) {
        location.reload();
      }
    });
}, 5000);
</script>

<?php if ($new_opponent): ?>
<audio autoplay>
  <source src="https://www.soundjay.com/buttons/sounds/button-09.mp3" type="audio/mpeg">
</audio>
<?php endif; ?>






