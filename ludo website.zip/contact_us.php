<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Us - SuperLudo.online</title>
  <style>
    body {
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
      background-color: #eef2f7;
      color: #333;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 60px auto;
      background: #fff;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    h1 {
      text-align: center;
      color: #444;
    }
    p {
      font-size: 16px;
      line-height: 1.6;
      margin: 15px 0;
    }
    .info {
      margin-top: 30px;
    }
    a {
      color: #c62828;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
    footer {
      text-align: center;
      margin-top: 40px;
      font-size: 14px;
      color: #888;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Contact Us</h1>
    <p>We’d love to hear from you! Whether you have a question about gameplay, payment, or anything else, our support team is ready to help.</p>

    <div class="info">
      <p><strong>Email:</strong> <a href="mailto:support@superludo.online">support@superludo.online</a></p>
      <p><strong>Phone:</strong> [+91 9588170734]</p>
      <p><strong>Address:</strong> [Mao, Gurgaon, Haryana]</p>
    </div>

    <footer>
      &copy; 2025 SuperLudo.online
    </footer>
  </div>
</body>
</html>
