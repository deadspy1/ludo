<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Terms and Conditions - SuperLudo.online</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f7fa;
      color: #333;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 900px;
      margin: 40px auto;
      background: #fff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 0 15px rgba(0,0,0,0.05);
    }
    h1 {
      color: #111;
      text-align: center;
    }
    h2 {
      margin-top: 30px;
      color: #222;
    }
    ul, p {
      line-height: 1.7;
      margin: 10px 0;
    }
    footer {
      text-align: center;
      margin-top: 40px;
      color: #777;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Terms and Conditions</h1>
    <p><strong>Effective Date:</strong> [10/05/2025]</p>

    <h2>1. Acceptance of Terms</h2>
    <p>By using SuperLudo.online, you agree to these terms. If you do not agree, please do not use the service.</p>

    <h2>2. Eligibility</h2>
    <p>You must be at least 18 years old to participate.</p>

    <h2>3. Account Use</h2>
    <p>Users must register with accurate info and keep login details secure. Misuse or multiple accounts may result in a ban.</p>

    <h2>4. Payments & Withdrawals</h2>
    <p>All payments are handled securely. Winnings may require KYC verification before withdrawal.</p>

    <h2>5. Prohibited Conduct</h2>
    <ul>
      <li>Cheating, using bots, or tampering with game mechanics</li>
      <li>Using false information or impersonating others</li>
      <li>Engaging in fraud or payment abuse</li>
    </ul>

    <h2>6. Liability</h2>
    <p>We are not responsible for data loss, financial loss, or service interruptions.</p>

    <h2>7. Changes</h2>
    <p>We may update these terms at any time. Continued use implies acceptance.</p>

    <h2>8. Governing Law</h2>
    <p>These terms are governed by the laws of India. Disputes will be resolved in [Your City], India.</p>

    <h2>9. Contact</h2>
    <p>Email: <a href="mailto:support@superludo.online">support@superludo.online</a></p>

    <footer>&copy; 2025 SuperLudo.online. All rights reserved.</footer>
  </div>
</body>
</html>
