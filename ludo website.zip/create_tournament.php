<?php
require 'includes/db.php';
require 'includes/auth.php'; // Ensure user is logged in

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $entry_fee = floatval($_POST['entry_fee']);
    $prize_pool = floatval($_POST['prize_pool']);
    $created_by = $_SESSION['user_id'];

    if ($name) {
        $stmt = $pdo->prepare("INSERT INTO tournaments (name, entry_fee, prize_pool, created_by) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $entry_fee, $prize_pool, $created_by]);
        $success = "Tournament created successfully!";
    } else {
        $error = "Tournament name is required.";
    }
}
?>

<h2>Create Tournament</h2>
<form method="POST">
    <input type="text" name="name" placeholder="Tournament Name" required /><br/>
    <input type="number" step="0.01" name="entry_fee" placeholder="Entry Fee" /><br/>
    <input type="number" step="0.01" name="prize_pool" placeholder="Prize Pool" /><br/>
    <button type="submit">Create</button>
</form>

<?php
if (isset($success)) echo "<p style='color:green;'>$success</p>";
if (isset($error)) echo "<p style='color:red;'>$error</p>";
?>
