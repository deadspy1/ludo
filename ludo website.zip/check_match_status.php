<?php
session_start();
require 'includes/db.php';

$match_id = $_SESSION['match_id'] ?? 0;

if (!$match_id) {
    echo json_encode(['status' => 'invalid']);
    exit;
}

$stmt = $pdo->prepare("SELECT player2_id FROM matches WHERE id = ?");
$stmt->execute([$match_id]);
$match = $stmt->fetch();

if (!$match) {
    echo json_encode(['status' => 'cancelled']);
    exit;
}

if ($match['player2_id']) {
    echo json_encode(['status' => 'opponent_joined']);
} else {
    echo json_encode(['status' => 'waiting']);
}
